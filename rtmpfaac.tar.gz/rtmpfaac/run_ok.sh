#! /bin/sh
export LD_LIBRARY_PATH=./lib:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=./libr:$LD_LIBRARY_PATH
#./rtsp-h264 rtmp://192.168.1.63/live/test
./rtmplin rtmp://192.168.1.163/live/stream
# ./rtmpjian rtmp://192.168.1.163/live
