/******************************************************************************
  A simple program of Hisilicon HI3516 audio input/output/encoder/decoder implementation.
  Copyright (C), 2010-2011, Hisilicon Tech. Co., Ltd.
 ******************************************************************************
    Modification:  2011-2 Created
******************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <pthread.h>
#include <errno.h>
#include <signal.h>

#include "sample_comm.h"
#include "acodec.h"
// #include "audio_amr_adp.h"
#include "audio_aac_adp.h"
// #include "audio_mp3_adp.h"


static HI_BOOL gs_bAioReSample = HI_FALSE;
#define TEST_AIO_ID        0
#define AIO_WORK_MODE      AIO_MODE_I2S_MASTER

static PAYLOAD_TYPE_E gs_enPayloadType = PT_AAC;
static AUDIO_SAMPLE_RATE_E enInSampleRate  = AUDIO_SAMPLE_RATE_BUTT;
static AUDIO_SAMPLE_RATE_E enOutSampleRate = AUDIO_SAMPLE_RATE_BUTT;


// static AMR_FORMAT_E AMR_FORMAT = AMR_FORMAT_MMS;   	/* AMR_FORMAT_MMS, AMR_FORMAT_IF1, AMR_FORMAT_IF2*/
// static AMR_MODE_E 	AMR_MODE   = AMR_MODE_MR74; 	/* AMR_MODE_MR122, AMR_MODE_MR102 ... */
// static HI_S32 		AMR_DTX    = 0;

static AAC_TYPE_E 	gs_enAacType = AAC_TYPE_AACLC; 
static AAC_BPS_E 	gs_enAacBps  = AAC_BPS_96K;
// static MP3_BPS_E 	gs_enMp3Bps  = MP3_BPS_128K;

static HI_BOOL gs_bUserGetMode = HI_FALSE;

//static HI_BOOL gs_bMicIn = HI_FALSE;
//static HI_U32 g_InnerCodecInput = 1; /*0-micin 1-linein 2-micind 3-lineind*/
//static HI_U32 g_InnerCodecOutput = 0; /*0-lineout 1-leftd 2-rightd*/


#define SAMPLE_DBG(s32Ret)\
do{\
    printf("s32Ret=%#x,fuc:%s,line:%d\n", s32Ret, __FUNCTION__, __LINE__);\
}while(0)

/******************************************************************************
* function : PT Number to String
******************************************************************************/
static char* SAMPLE_AUDIO_Pt2Str(PAYLOAD_TYPE_E enType)
{
    if (PT_AMR == enType)  return "amrnb";
    else if (PT_AAC == enType)  return "aac";
    else if (PT_MP3 == enType)  return "mp3";
    else return "data";
}

/******************************************************************************
* function : Open Aenc File
******************************************************************************/
static FILE * SAMPLE_AUDIO_OpenAencFile(AENC_CHN AeChn, PAYLOAD_TYPE_E enType)
{
    FILE *pfd;
    HI_CHAR aszFileName[128];
    
    /* create file for save stream*/
    sprintf(aszFileName, "audio_chn%d.%s", AeChn, SAMPLE_AUDIO_Pt2Str(enType));
    pfd = fopen(aszFileName, "w+");
    if (NULL == pfd)
    {
        printf("%s: open file %s failed\n", __FUNCTION__, aszFileName);
        return NULL;
    }
    printf("open stream file:\"%s\" for aenc ok\n", aszFileName);
    return pfd;
}

/******************************************************************************
* function : Open Adec File
******************************************************************************/
static FILE *SAMPLE_AUDIO_OpenAdecFile(ADEC_CHN AdChn, PAYLOAD_TYPE_E enType)
{
    FILE *pfd;
    HI_CHAR aszFileName[128];
    
    /* create file for save stream*/        
    sprintf(aszFileName, "audio_chn%d.%s", AdChn, SAMPLE_AUDIO_Pt2Str(enType));
    pfd = fopen(aszFileName, "rb");
    if (NULL == pfd)
    {
        printf("%s: open file %s failed\n", __FUNCTION__, aszFileName);
        return NULL;
    }
    printf("open stream file:\"%s\" for adec ok\n", aszFileName);
    return pfd;
}

/******************************************************************************
* function : Start Aenc
******************************************************************************/
HI_S32 SAMPLE_AUDIO_StartAenc(HI_S32 s32AencChnCnt, AIO_ATTR_S *pstAioAttr, PAYLOAD_TYPE_E enType)
{
    AENC_CHN AeChn;
    HI_S32 s32Ret, i;
    AENC_CHN_ATTR_S stAencAttr;
    // AENC_ATTR_AMR_S stAencAmr;
    AENC_ATTR_AAC_S stAencAac;
    // AENC_ATTR_MP3_S stAencMp3;
    
    /* set AENC chn attr */    
    stAencAttr.enType = enType;
    stAencAttr.u32BufSize = 30;
	stAencAttr.u32PtNumPerFrm = pstAioAttr->u32PtNumPerFrm;

    // if (PT_AMR == stAencAttr.enType)
    // {
        
    //     stAencAttr.pValue = &stAencAmr;
    //     stAencAmr.enFormat = AMR_FORMAT ;
    //     stAencAmr.enMode = AMR_MODE ;
    //     stAencAmr.s32Dtx = AMR_DTX ;
    // }
     if (PT_AAC == stAencAttr.enType)
    {
        
        stAencAttr.pValue = &stAencAac;
        stAencAac.enAACType = gs_enAacType;
        stAencAac.enBitRate = gs_enAacBps;
        stAencAac.enBitWidth = AUDIO_BIT_WIDTH_16;
        stAencAac.enSmpRate = pstAioAttr->enSamplerate;
        stAencAac.enSoundMode = pstAioAttr->enSoundmode;
    }
    // else if (PT_MP3 == stAencAttr.enType)
    // {
        
    //     stAencAttr.pValue = &stAencMp3;
    //     stAencMp3.enBitRate = gs_enMp3Bps;
    //     stAencMp3.enBitWidth = AUDIO_BIT_WIDTH_16;
    //     stAencMp3.enLayer = MP3_LAYER_3;
    //     stAencMp3.enVersion = MPEG_1;
    //     stAencMp3.enAiSoundMode = pstAioAttr->enSoundmode;
    //     stAencMp3.enSmpRate = pstAioAttr->enSamplerate;
    // }
    else
    {
        printf("%s: invalid aenc payload type:%d\n", __FUNCTION__, stAencAttr.enType);
        return HI_FAILURE;
    }    

    for (i=0; i<s32AencChnCnt; i++)
    {            
        AeChn = i;
        
        /* create aenc chn*/
        s32Ret = HI_MPI_AENC_CreateChn(AeChn, &stAencAttr);
        if (s32Ret != HI_SUCCESS)
        {
            printf("%s: HI_MPI_AENC_CreateChn(%d) failed with %#x!\n", __FUNCTION__,
                   AeChn, s32Ret);
            return HI_FAILURE;
        }        
    }
    
    return HI_SUCCESS;
}

/******************************************************************************
* function : Start Adec
******************************************************************************/
HI_S32 SAMPLE_AUDIO_StartAdec(ADEC_CHN AdChn, PAYLOAD_TYPE_E enType)
{
    HI_S32 s32Ret;
    ADEC_CHN_ATTR_S stAdecAttr;
    // ADEC_ATTR_AMR_S stAdecAmr;
    ADEC_ATTR_AAC_S stAdecAac;
    // ADEC_ATTR_MP3_S stAdecMp3;
        
    stAdecAttr.enType = enType;
    stAdecAttr.u32BufSize = 20;
    stAdecAttr.enMode = ADEC_MODE_STREAM;/* propose use pack mode in your app */
        
    // if (PT_AMR == stAdecAttr.enType)
    // {
    //     stAdecAttr.pValue = &stAdecAmr;
    //     stAdecAmr.enFormat = AMR_FORMAT;
    // }
     if (PT_AAC == stAdecAttr.enType)
    {
        stAdecAttr.pValue = &stAdecAac;
        stAdecAttr.enMode = ADEC_MODE_STREAM;   /* aac should be stream mode */
    }    
    // else if (PT_MP3 == stAdecAttr.enType)
    // {
    //     stAdecAttr.pValue = &stAdecMp3;
    // }
    else
    {
        printf("%s: invalid aenc payload type:%d\n", __FUNCTION__, stAdecAttr.enType);
        return HI_FAILURE;
    }     
    
    /* create adec chn*/
    s32Ret = HI_MPI_ADEC_CreateChn(AdChn, &stAdecAttr);
    if (s32Ret)
    {
        printf("%s: HI_MPI_ADEC_CreateChn(%d) failed with %#x!\n", __FUNCTION__,\
               AdChn,s32Ret);
        return s32Ret;
    }
    return 0;
}

/******************************************************************************
* function : file -> ADec -> Ao
******************************************************************************/
HI_S32 SAMPLE_AUDIO_AdecAo(AIO_ATTR_S *pstAioAttr)
{
    HI_S32      s32Ret;
#ifdef AO_DEV
    AUDIO_DEV 	AoDev = AO_DEV;
#else
	AUDIO_DEV 	AoDev = TEST_AIO_ID;
#endif
    AO_CHN      AoChn = 0;
    ADEC_CHN    AdChn = 0;
	HI_S32 		s32AoChnCnt;
    FILE        *pfd = NULL;

    if (NULL == pstAioAttr)
    {
        printf("%s: input piont is invalid!\n", __FUNCTION__);
        return HI_FAILURE;
    }

    s32Ret = SAMPLE_COMM_AUDIO_CfgAcodec(pstAioAttr);
    if (HI_SUCCESS != s32Ret)
    {
        SAMPLE_DBG(s32Ret);
        return HI_FAILURE;
    }
    
    s32Ret = SAMPLE_AUDIO_StartAdec(AdChn, gs_enPayloadType);
    if (s32Ret != HI_SUCCESS)
    {
        SAMPLE_DBG(s32Ret);
        return HI_FAILURE;
    }

	s32AoChnCnt = pstAioAttr->u32ChnCnt;
    // s32Ret = SAMPLE_COMM_AUDIO_StartAo(AoDev, s32AoChnCnt, pstAioAttr, AUDIO_SAMPLE_RATE_BUTT, HI_FALSE);
    s32Ret = SAMPLE_COMM_AUDIO_StartAo(AoDev, s32AoChnCnt, &pstAioAttr, enInSampleRate, gs_bAioReSample, NULL , 0);
    if (s32Ret != HI_SUCCESS)
    {
        SAMPLE_DBG(s32Ret);
        return HI_FAILURE;
    }

    s32Ret = SAMPLE_COMM_AUDIO_AoBindAdec(AoDev, AoChn, AdChn);
    if (s32Ret != HI_SUCCESS)
    {
        SAMPLE_DBG(s32Ret);
        return HI_FAILURE;
    }

    pfd = SAMPLE_AUDIO_OpenAdecFile(AdChn, gs_enPayloadType);
    if (!pfd)
    {
        SAMPLE_DBG(HI_FAILURE);
        return HI_FAILURE;
    }
    
    s32Ret = SAMPLE_COMM_AUDIO_CreatTrdFileAdec(AdChn, pfd);
    if (s32Ret != HI_SUCCESS)
    {
        SAMPLE_DBG(s32Ret);
        return HI_FAILURE;
    }
    
    printf("bind adec:%d to ao(%d,%d) ok \n", AdChn, AoDev, AoChn);

    printf("\nplease press twice ENTER to exit this sample\n");
    getchar();
    getchar();

    SAMPLE_COMM_AUDIO_DestoryTrdFileAdec(AdChn);
    SAMPLE_COMM_AUDIO_AoUnbindAdec(AoDev, AoChn, AdChn);
    // SAMPLE_COMM_AUDIO_StopAo(AoDev, s32AoChnCnt, HI_FALSE); s32AoChnCnt
    SAMPLE_COMM_AUDIO_StopAo(AoDev, s32AoChnCnt, gs_bAioReSample, HI_FALSE);
    SAMPLE_COMM_AUDIO_StopAdec(AdChn);
    
    return HI_SUCCESS;
}

/******************************************************************************
* function : Ai -> Aenc -> file
*                                -> Adec -> Ao
******************************************************************************/
#if 0
HI_S32 SAMPLE_AUDIO_AiAenc(AIO_ATTR_S *pstAioAttr)
{
    HI_S32 i, s32Ret;
#ifdef AI_DEV
	AUDIO_DEV   AiDev = AI_DEV;
	AUDIO_DEV 	AoDev = AO_DEV;
#else
	AUDIO_DEV   AiDev = TEST_AIO_ID;
	AUDIO_DEV 	AoDev = TEST_AIO_ID;
#endif
    
    AI_CHN      AiChn;
    
    AO_CHN      AoChn = 0;
    ADEC_CHN    AdChn = 0;
    HI_S32      s32AiChnCnt;
	HI_S32      s32AoChnCnt;
    HI_S32      s32AencChnCnt;
    AENC_CHN    AeChn;
    HI_BOOL     bSendAdec = HI_TRUE;
    FILE        *pfd = NULL;

    /* config ai aenc dev attr */
    if (NULL == pstAioAttr)
    {
        printf("%s: input piont is invalid!\n", __FUNCTION__);
        return HI_FAILURE;
    }

    /********************************************
      step 1: config audio codec
    ********************************************/
    s32Ret = SAMPLE_COMM_AUDIO_CfgAcodec(pstAioAttr);
    if (HI_SUCCESS != s32Ret)
    {
        SAMPLE_DBG(s32Ret);
        return HI_FAILURE;
    }

    /********************************************
      step 2: start Ai
    ********************************************/
    s32AiChnCnt = pstAioAttr->u32ChnCnt; 
    s32AencChnCnt = 1;//s32AiChnCnt;
    s32Ret = SAMPLE_COMM_AUDIO_StartAi(AiDev, s32AiChnCnt, pstAioAttr, AUDIO_SAMPLE_RATE_BUTT, HI_FALSE, NULL);
    if (s32Ret != HI_SUCCESS)
    {
        SAMPLE_DBG(s32Ret);
        return HI_FAILURE;
    }

    /********************************************
      step 3: start Aenc
    ********************************************/
    s32Ret = SAMPLE_AUDIO_StartAenc(s32AencChnCnt, pstAioAttr, gs_enPayloadType);
    if (s32Ret != HI_SUCCESS)
    {
        SAMPLE_DBG(s32Ret);
        return HI_FAILURE;
    }

    /********************************************
      step 4: Aenc bind Ai Chn
    ********************************************/
    for (i=0; i<s32AencChnCnt; i++)
    {
        AeChn = i;
        AiChn = i;

        if (HI_TRUE == gs_bUserGetMode)
        {
            s32Ret = SAMPLE_COMM_AUDIO_CreatTrdAiAenc(AiDev, AiChn, AeChn);
            if (s32Ret != HI_SUCCESS)
            {
                SAMPLE_DBG(s32Ret);
                return HI_FAILURE;
            }
        }
        else
        {        
            s32Ret = SAMPLE_COMM_AUDIO_AencBindAi(AiDev, AiChn, AeChn);
            if (s32Ret != HI_SUCCESS)
            {
                SAMPLE_DBG(s32Ret);
                return s32Ret;
            }
        }
        printf("Ai(%d,%d) bind to AencChn:%d ok!\n",AiDev , AiChn, AeChn);
    }

    /********************************************
      step 5: start Adec & Ao. ( if you want )
    ********************************************/
    if (HI_TRUE == bSendAdec)
    {
        s32Ret = SAMPLE_AUDIO_StartAdec(AdChn, gs_enPayloadType);
        if (s32Ret != HI_SUCCESS)
        {
            SAMPLE_DBG(s32Ret);
            return HI_FAILURE;
        }

		s32AoChnCnt = pstAioAttr->u32ChnCnt;
        s32Ret = SAMPLE_COMM_AUDIO_StartAo(AoDev, s32AoChnCnt, pstAioAttr, AUDIO_SAMPLE_RATE_BUTT, HI_FALSE);
        if (s32Ret != HI_SUCCESS)
        {
            SAMPLE_DBG(s32Ret);
            return HI_FAILURE;
        }

        pfd = SAMPLE_AUDIO_OpenAencFile(AdChn, gs_enPayloadType);
        if (!pfd)
        {
            SAMPLE_DBG(HI_FAILURE);
            return HI_FAILURE;
        } 
        s32Ret = SAMPLE_COMM_AUDIO_CreatTrdAencAdec(AeChn, AdChn, pfd);
        if (s32Ret != HI_SUCCESS)
        {
            SAMPLE_DBG(s32Ret);
            return HI_FAILURE;
        }

        s32Ret = SAMPLE_COMM_AUDIO_AoBindAdec(AoDev, AoChn, AdChn);
        if (s32Ret != HI_SUCCESS)
        {
            SAMPLE_DBG(s32Ret);
            return HI_FAILURE;
        }

        printf("bind adec:%d to ao(%d,%d) ok \n", AdChn, AoDev, AoChn);
    }

    printf("\nplease press twice ENTER to exit this sample\n");
    getchar();
    getchar();

    /********************************************
      step 6: exit the process
    ********************************************/
    if (HI_TRUE == bSendAdec)
    {
        SAMPLE_COMM_AUDIO_AoUnbindAdec(AoDev, AoChn, AdChn);
        SAMPLE_COMM_AUDIO_DestoryTrdAencAdec(AdChn);
        SAMPLE_COMM_AUDIO_StopAo(AoDev, s32AoChnCnt, HI_FALSE);
        SAMPLE_COMM_AUDIO_StopAdec(AdChn);
    }
    
    for (i=0; i<s32AencChnCnt; i++)
    {
        AeChn = i;
        AiChn = i;

        if (HI_TRUE == gs_bUserGetMode)
        {
            SAMPLE_COMM_AUDIO_DestoryTrdAi(AiDev, AiChn);
        }
        else
        {        
            SAMPLE_COMM_AUDIO_AencUnbindAi(AiDev, AiChn, AeChn);
        }
    }
    
    SAMPLE_COMM_AUDIO_StopAenc(s32AencChnCnt);
    SAMPLE_COMM_AUDIO_StopAi(AiDev, s32AiChnCnt, HI_FALSE, HI_FALSE);

    return HI_SUCCESS;
}
#endif
/******************************************************************************
* function : Ai -> Aenc -> file
*                                -> Adec -> Ao
******************************************************************************/
#if 1
HI_S32 SAMPLE_AUDIO_AiAencAdecAO(AIO_ATTR_S *pstAioAttr)
{
    HI_S32 i, s32Ret;

#ifdef AO_DEV
	AUDIO_DEV   AiDev = AI_DEV;
	AUDIO_DEV 	AoDev = AO_DEV;
#else
	AUDIO_DEV   AiDev = TEST_AIO_ID;
	AUDIO_DEV 	AoDev = TEST_AIO_ID;
#endif

    AI_CHN      AiChn;
    AO_CHN      AoChn = 0;
    ADEC_CHN    AdChn = 0;
    HI_S32      s32AiChnCnt;
	HI_S32      s32AoChnCnt;
    HI_S32      s32AencChnCnt;
    AENC_CHN    AeChn;
    HI_BOOL     bSendAdec = HI_TRUE;
    FILE        *pfd = NULL;
    enInSampleRate  = AUDIO_SAMPLE_RATE_BUTT;
    enOutSampleRate = AUDIO_SAMPLE_RATE_BUTT;

    /* config ai aenc dev attr */
    if (NULL == pstAioAttr)
    {
        printf("%s: input piont is invalid!\n", __FUNCTION__);
        return HI_FAILURE;
    }
	

    /********************************************
      step 1: config audio codec
    ********************************************/
    s32Ret = SAMPLE_COMM_AUDIO_CfgAcodec(pstAioAttr);
    if (HI_SUCCESS != s32Ret)
    {
        SAMPLE_DBG(s32Ret);
        return HI_FAILURE;
    }

    /********************************************
      step 2: start Ai
    ********************************************/
    s32AiChnCnt = pstAioAttr->u32ChnCnt; 
    s32AencChnCnt = s32AiChnCnt;
    // s32Ret = SAMPLE_COMM_AUDIO_StartAi(AiDev, s32AiChnCnt, pstAioAttr, AUDIO_SAMPLE_RATE_BUTT, HI_FALSE, NULL);
    s32Ret = SAMPLE_COMM_AUDIO_StartAi(AiDev, s32AiChnCnt, pstAioAttr, enOutSampleRate, gs_bAioReSample, NULL, 0);
    if (s32Ret != HI_SUCCESS)
    {
        SAMPLE_DBG(s32Ret);
        return HI_FAILURE;
    }

    /********************************************
      step 3: start Aenc
    ********************************************/
    s32Ret = SAMPLE_AUDIO_StartAenc(s32AencChnCnt, pstAioAttr, gs_enPayloadType);
    if (s32Ret != HI_SUCCESS)
    {
        SAMPLE_DBG(s32Ret);
        return HI_FAILURE;
    }

    /********************************************
      step 4: Aenc bind Ai Chn
    ********************************************/
    for (i=0; i<s32AencChnCnt; i++)
    {
        AeChn = i;
        AiChn = i;

        if (HI_TRUE == gs_bUserGetMode)
        {
            s32Ret = SAMPLE_COMM_AUDIO_CreatTrdAiAenc(AiDev, AiChn, AeChn);
            if (s32Ret != HI_SUCCESS)
            {
                SAMPLE_DBG(s32Ret);
                return HI_FAILURE;
            }
        }
        else
        {        
            s32Ret = SAMPLE_COMM_AUDIO_AencBindAi(AiDev, AiChn, AeChn);
            if (s32Ret != HI_SUCCESS)
            {
                SAMPLE_DBG(s32Ret);
                return s32Ret;
            }
        }
        printf("Ai(%d,%d) bind to AencChn:%d ok!\n",AiDev , AiChn, AeChn);
    }

    /********************************************
      step 5: start Adec & Ao. ( if you want )
    ********************************************/
    if (HI_TRUE == bSendAdec)
    {
        s32Ret = SAMPLE_AUDIO_StartAdec(AdChn, gs_enPayloadType);
        if (s32Ret != HI_SUCCESS)
        {
            SAMPLE_DBG(s32Ret);
            return HI_FAILURE;
        }

		s32AoChnCnt = pstAioAttr->u32ChnCnt;
        // s32Ret = SAMPLE_COMM_AUDIO_StartAo(AoDev, s32AoChnCnt, pstAioAttr, AUDIO_SAMPLE_RATE_BUTT, HI_FALSE);
        SAMPLE_COMM_AUDIO_StartAo(AoDev, s32AoChnCnt, &pstAioAttr, enInSampleRate, gs_bAioReSample, NULL , 0);
        if (s32Ret != HI_SUCCESS)
        {
            SAMPLE_DBG(s32Ret);
            return HI_FAILURE;
        }
		
        pfd = SAMPLE_AUDIO_OpenAencFile(AdChn, gs_enPayloadType);
        if (!pfd)
        {
            SAMPLE_DBG(HI_FAILURE);
            return HI_FAILURE;
        } 
        s32Ret = SAMPLE_COMM_AUDIO_CreatTrdAencAdec(AeChn, AdChn, pfd);
        if (s32Ret != HI_SUCCESS)
        {
            SAMPLE_DBG(s32Ret);
            return HI_FAILURE;
        }

        s32Ret = SAMPLE_COMM_AUDIO_AoBindAdec(AoDev, AoChn, AdChn);
        if (s32Ret != HI_SUCCESS)
        {
            SAMPLE_DBG(s32Ret);
            return HI_FAILURE;
        }

        printf("bind adec:%d to ao(%d,%d) ok \n", AdChn, AoDev, AoChn);
    }

    printf("\nplease press twice ENTER to exit this sample\n");
    getchar();
    getchar();

    /********************************************
      step 6: exit the process
    ********************************************/
    if (HI_TRUE == bSendAdec)
    {
        SAMPLE_COMM_AUDIO_AoUnbindAdec(AoDev, AoChn, AdChn);
        SAMPLE_COMM_AUDIO_DestoryTrdAencAdec(AdChn);
        // SAMPLE_COMM_AUDIO_StopAo(AoDev, s32AoChnCnt, HI_FALSE);
        SAMPLE_COMM_AUDIO_StopAo(AoDev, s32AoChnCnt, gs_bAioReSample, HI_FALSE);
		
        SAMPLE_COMM_AUDIO_StopAdec(AdChn);
    }
    
    for (i=0; i<s32AencChnCnt; i++)
    {
        AeChn = i;
        AiChn = i;

        if (HI_TRUE == gs_bUserGetMode)
        {
            SAMPLE_COMM_AUDIO_DestoryTrdAi(AiDev, AiChn);
        }
        else
        {        
            SAMPLE_COMM_AUDIO_AencUnbindAi(AiDev, AiChn, AeChn);
        }
    }
    
    SAMPLE_COMM_AUDIO_StopAenc(s32AencChnCnt);
    SAMPLE_COMM_AUDIO_StopAi(AiDev, s32AiChnCnt, HI_FALSE, HI_FALSE);

    return HI_SUCCESS;
}
#endif
#if 0
HI_S32 SAMPLE_AUDIO_AiAo(AIO_ATTR_S *stAioAttr)
{
    HI_S32 s32Ret;
    HI_S32 s32AiChnCnt;
    HI_S32 s32AoChnCnt;
    AUDIO_DEV   AiDev = SAMPLE_AUDIO_AI_DEV;
    AI_CHN      AiChn = 0;
    AUDIO_DEV   AoDev = SAMPLE_AUDIO_AO_DEV;
    AO_CHN      AoChn = 0;
    // AIO_ATTR_S stAioAttr;

#ifdef HI_ACODEC_TYPE_TLV320AIC31
    stAioAttr.enSamplerate   = AUDIO_SAMPLE_RATE_8000;
    stAioAttr.enBitwidth     = AUDIO_BIT_WIDTH_16;
    stAioAttr.enWorkmode     = AIO_MODE_I2S_MASTER;
    stAioAttr.enSoundmode    = AUDIO_SOUND_MODE_MONO;
    stAioAttr.u32EXFlag      = 0;
    stAioAttr.u32FrmNum      = 30;
    stAioAttr.u32PtNumPerFrm = SAMPLE_AUDIO_PTNUMPERFRM;
    stAioAttr.u32ChnCnt      = 1;
    stAioAttr.u32ClkSel      = 1;
#else //  inner acodec
    stAioAttr.enSamplerate   = AUDIO_SAMPLE_RATE_8000;
    stAioAttr.enBitwidth     = AUDIO_BIT_WIDTH_16;
    stAioAttr.enWorkmode     = AIO_MODE_I2S_MASTER;
    stAioAttr.enSoundmode    = AUDIO_SOUND_MODE_MONO;
    stAioAttr.u32EXFlag      = 0;
    stAioAttr.u32FrmNum      = 30;
    stAioAttr.u32PtNumPerFrm = SAMPLE_AUDIO_PTNUMPERFRM;
    stAioAttr.u32ChnCnt      = 1;
    stAioAttr.u32ClkSel      = 0;
#endif
    /* config ao resample attr if needed */
    if (HI_TRUE == gs_bAioReSample)
    {
        stAioAttr.enSamplerate   = AUDIO_SAMPLE_RATE_32000;
        stAioAttr.u32PtNumPerFrm = SAMPLE_AUDIO_PTNUMPERFRM * 4;

        /* ai 32k -> 8k */
        enOutSampleRate = AUDIO_SAMPLE_RATE_8000;

        /* ao 8k -> 32k */
        enInSampleRate  = AUDIO_SAMPLE_RATE_8000;
    }
    else
    {
        enInSampleRate  = AUDIO_SAMPLE_RATE_BUTT;
        enOutSampleRate = AUDIO_SAMPLE_RATE_BUTT;
    }

    /* resample and anr should be user get mode */
    gs_bUserGetMode = (HI_TRUE == gs_bAioReSample) ? HI_TRUE : HI_FALSE;
    
    /* config internal audio codec */
    s32Ret = SAMPLE_COMM_AUDIO_CfgAcodec(&stAioAttr);
    if (HI_SUCCESS != s32Ret)
    {
        SAMPLE_DBG(s32Ret);
        goto AIAO_ERR3;
    }
    
    /* enable AI channle */
    s32AiChnCnt = stAioAttr.u32ChnCnt >> stAioAttr.enSoundmode;
    s32Ret = SAMPLE_COMM_AUDIO_StartAi(AiDev, s32AiChnCnt, &stAioAttr, enOutSampleRate, gs_bAioReSample, NULL, 0);
    if (s32Ret != HI_SUCCESS)
    {
        SAMPLE_DBG(s32Ret);
        goto AIAO_ERR3;
    }

    /* enable AO channle */
    s32AoChnCnt = stAioAttr.u32ChnCnt >> stAioAttr.enSoundmode;
    s32Ret = SAMPLE_COMM_AUDIO_StartAo(AoDev, s32AoChnCnt, &stAioAttr, enInSampleRate, gs_bAioReSample, NULL, 0);
    if (s32Ret != HI_SUCCESS)
    {
        SAMPLE_DBG(s32Ret);
         goto AIAO_ERR2;
    }

    /* bind AI to AO channle */
    if (HI_TRUE == gs_bUserGetMode)
    {
        s32Ret = SAMPLE_COMM_AUDIO_CreatTrdAiAo(AiDev, AiChn, AoDev, AoChn);
        if (s32Ret != HI_SUCCESS)
        {
            SAMPLE_DBG(s32Ret);
             goto AIAO_ERR1;
        }
    }
    else
    {
        s32Ret = SAMPLE_COMM_AUDIO_AoBindAi(AiDev, AiChn, AoDev, AoChn);
        if (s32Ret != HI_SUCCESS)
        {
            SAMPLE_DBG(s32Ret);
            goto AIAO_ERR1;
        }
    }
    printf("ai(%d,%d) bind to ao(%d,%d) ok\n", AiDev, AiChn, AoDev, AoChn);

    if (HI_TRUE == gs_bAoVolumeCtrl)
    {
        s32Ret = SAMPLE_COMM_AUDIO_CreatTrdAoVolCtrl(AoDev);
        if (s32Ret != HI_SUCCESS)
        {
            SAMPLE_DBG(s32Ret);
            goto AIAO_ERR0;
        }
    }

    printf("\nplease press twice ENTER to exit this sample\n");
    getchar();
    getchar();

    if (HI_TRUE == gs_bAoVolumeCtrl)
    {
        s32Ret = SAMPLE_COMM_AUDIO_DestoryTrdAoVolCtrl(AoDev);
        if (s32Ret != HI_SUCCESS)
        {
            SAMPLE_DBG(s32Ret);
            return HI_FAILURE;
        }
    }
    
AIAO_ERR0:

    if (HI_TRUE == gs_bUserGetMode)
    {
        s32Ret = SAMPLE_COMM_AUDIO_DestoryTrdAi(AiDev, AiChn);
        if (s32Ret != HI_SUCCESS)
        {
            SAMPLE_DBG(s32Ret);
        }
    }
    else
    {
        s32Ret = SAMPLE_COMM_AUDIO_AoUnbindAi(AiDev, AiChn, AoDev, AoChn);
        if (s32Ret != HI_SUCCESS)
        {
            SAMPLE_DBG(s32Ret);
        }
    }
    
AIAO_ERR1:
    
    s32Ret |= SAMPLE_COMM_AUDIO_StopAo(AoDev, s32AoChnCnt, gs_bAioReSample, HI_FALSE);
    if (s32Ret != HI_SUCCESS)
    {
        SAMPLE_DBG(s32Ret);
    }
    
AIAO_ERR2:
    s32Ret |= SAMPLE_COMM_AUDIO_StopAi(AiDev, s32AiChnCnt, gs_bAioReSample, HI_FALSE);
    if (s32Ret != HI_SUCCESS)
    {
        SAMPLE_DBG(s32Ret);
    }
    
AIAO_ERR3:

    return s32Ret;
}
#endif

HI_VOID SAMPLE_AUDIO_Usage(void)
{
    printf("\n/************************************/\n");
    printf("press sample command as follows!\n");
    printf("1:  send audio frame to AENC channel form AI, save them\n");
    printf("2:  read audio stream from file,decode and send AO\n");
    printf("3:  send audio frame to AENC channel form AI,decode and send AO\n");
    printf("q:  quit whole audio sample\n\n");
    printf("sample command:");
}

/******************************************************************************
* function : to process abnormal case
******************************************************************************/
void SAMPLE_AUDIO_HandleSig(HI_S32 signo)
{
    if (SIGINT == signo || SIGTSTP == signo)
    {
        SAMPLE_COMM_AUDIO_DestoryAllTrd();
        SAMPLE_COMM_SYS_Exit();
        printf("\033[0;31mprogram exit abnormally!\033[0;39m\n");
    }

    exit(0);
}

/******************************************************************************
* function : main
******************************************************************************/
#if 0
HI_S32 main(int argc, char *argv[])
{
    char ch;
    HI_S32 s32Ret= HI_SUCCESS;
    VB_CONF_S stVbConf;
    AIO_ATTR_S stAioAttr;

    /* arg 1 is audio payload type */
    if (argc >= 2)
    {
        gs_enPayloadType = atoi(argv[1]);

        if (gs_enPayloadType != PT_AMR && gs_enPayloadType != PT_AAC)
        {
            printf("payload type invalid!\n");
            printf("\nargv[1]:%d is payload type ID, suport such type:\n", gs_enPayloadType);
            printf("%d:amr, %d:aac, %d:mp3\n", PT_AMR, PT_AAC, PT_MP3);
            return HI_FAILURE;
        }
    }

    /* init stAio. all of cases will use it */
    memset(&stAioAttr, 0, sizeof(AIO_ATTR_S));
    stAioAttr.enBitwidth = AUDIO_BIT_WIDTH_16;
    stAioAttr.enWorkmode = AIO_WORK_MODE;
    stAioAttr.enSoundmode = AUDIO_SOUND_MODE_MONO;
    stAioAttr.u32EXFlag = 0;
    stAioAttr.u32FrmNum = 30;
    stAioAttr.u32ChnCnt = 1;
    #ifdef HI_ACODEC_TYPE_TLV320AIC31
    stAioAttr.u32ClkSel = 1;
    #else
    stAioAttr.u32ClkSel = 0;
    #endif
    if (PT_AMR == gs_enPayloadType)
    {
        stAioAttr.enSamplerate = AUDIO_SAMPLE_RATE_8000;
        stAioAttr.u32PtNumPerFrm = 160;    
    }
    else if (PT_AAC == gs_enPayloadType)
    {
        stAioAttr.enSamplerate = AUDIO_SAMPLE_RATE_8000;
        stAioAttr.u32PtNumPerFrm = (AAC_TYPE_AACLC == gs_enAacType) ? 1024 : 2048; 
    }
    else if (PT_MP3 == gs_enPayloadType)
    {
        stAioAttr.enSamplerate = AUDIO_SAMPLE_RATE_48000;
        stAioAttr.u32PtNumPerFrm = 1152; 
    }
    else
    {
        printf("%s: invalid aenc payload type:%d\n", __FUNCTION__, gs_enPayloadType);
        return HI_FAILURE;
    }  

    signal(SIGINT, SAMPLE_AUDIO_HandleSig);
    signal(SIGTERM, SAMPLE_AUDIO_HandleSig);
    
    memset(&stVbConf, 0, sizeof(VB_CONF_S));
    s32Ret = SAMPLE_COMM_SYS_Init(&stVbConf);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: system init failed with %d!\n", __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }

    /* register amrnb/aac/mp3 encoder and decoder */
    HI_MPI_AENC_AmrInit();
    HI_MPI_AENC_AacInit();
    HI_MPI_ADEC_AmrInit();
    HI_MPI_ADEC_AacInit();
    HI_MPI_ADEC_Mp3Init();
    
    SAMPLE_AUDIO_Usage();
    
    while ((ch = getchar()) != 'q')
    {
        switch (ch)
        {
            case '1':
            {
                s32Ret = SAMPLE_AUDIO_AiAenc(&stAioAttr);/* send audio frame to AENC channel form AI, save them*/
                break;
            }
            case '2':
            {
                s32Ret = SAMPLE_AUDIO_AdecAo(&stAioAttr);/* read audio stream from file,decode and send AO*/
                break;
            }
            case '3':
            {
                s32Ret = SAMPLE_AUDIO_AiAencAdecAO(&stAioAttr);/* read audio stream from file,decode and send AO*/
                break;
            }
            default:
            {
                SAMPLE_AUDIO_Usage();
                break;
            }
        }
        if (s32Ret != HI_SUCCESS)
        {
            break;
        }
    }

    SAMPLE_COMM_SYS_Exit();

    return HI_SUCCESS;
}
#endif

// HI_S32 main(int argc, char *argv[])
  void *aacplayout(void *p)
{
    char ch;
    HI_S32 s32Ret= HI_SUCCESS;
    VB_CONF_S stVbConf;
    AIO_ATTR_S stAioAttr;

    /* arg 1 is audio payload type */
    // if (argc >= 2)
    // {
    //     gs_enPayloadType = atoi(argv[1]);

    //     if (gs_enPayloadType != PT_AMR && gs_enPayloadType != PT_AAC)
    //     {
    //         printf("payload type invalid!\n");
    //         printf("\nargv[1]:%d is payload type ID, suport such type:\n", gs_enPayloadType);
    //         printf("%d:amr, %d:aac, %d:mp3\n", PT_AMR, PT_AAC, PT_MP3);
    //         return HI_FAILURE;
    //     }
    // }

    /* init stAio. all of cases will use it */
    memset(&stAioAttr, 0, sizeof(AIO_ATTR_S));
    stAioAttr.enBitwidth   = AUDIO_BIT_WIDTH_16;
    // stAioAttr.enWorkmode = AIO_WORK_MODE;
    // stAioAttr.enSamplerate = AUDIO_SAMPLE_RATE_8000;
    stAioAttr.enWorkmode   = AIO_MODE_I2S_MASTER;
    stAioAttr.enSoundmode  = AUDIO_SOUND_MODE_MONO;
    stAioAttr.u32EXFlag = 0;
    stAioAttr.u32FrmNum = 30;
    stAioAttr.u32ChnCnt = 1;
    // stAioAttr.u32PtNumPerFrm = SAMPLE_AUDIO_PTNUMPERFRM;
    // #ifdef HI_ACODEC_TYPE_TLV320AIC31
    // stAioAttr.u32ClkSel = 1;
    // #else
    stAioAttr.u32ClkSel = 0;
    // #endif
    if (PT_AMR == gs_enPayloadType)
    {
        stAioAttr.enSamplerate = AUDIO_SAMPLE_RATE_8000;
        stAioAttr.u32PtNumPerFrm = 160;    
    }
    else if (PT_AAC == gs_enPayloadType)
    {
        stAioAttr.enSamplerate = AUDIO_SAMPLE_RATE_8000;
        stAioAttr.u32PtNumPerFrm = (AAC_TYPE_AACLC == gs_enAacType) ? 1024 : 2048; 
    }
    else if (PT_MP3 == gs_enPayloadType)
    {
        stAioAttr.enSamplerate = AUDIO_SAMPLE_RATE_48000;
        stAioAttr.u32PtNumPerFrm = 1152; 
    }
    else
    {
        printf("%s: invalid aenc payload type:%d\n", __FUNCTION__, gs_enPayloadType);
        return HI_FAILURE;
    }  

    signal(SIGINT, SAMPLE_AUDIO_HandleSig);
    signal(SIGTERM, SAMPLE_AUDIO_HandleSig);
    
    memset(&stVbConf, 0, sizeof(VB_CONF_S));
    // s32Ret = SAMPLE_COMM_SYS_Init(&stVbConf);
    // if (HI_SUCCESS != s32Ret)
    // {
    //     printf("%s: system init failed with %d!\n", __FUNCTION__, s32Ret);
    //     return HI_FAILURE;
    // }
    /* register amrnb/aac/mp3 encoder and decoder */
    // HI_MPI_AENC_AmrInit();
    HI_MPI_AENC_AacInit();
    // HI_MPI_ADEC_AmrInit();
    HI_MPI_ADEC_AacInit();
    // HI_MPI_ADEC_Mp3Init();
    
    // // SAMPLE_AUDIO_Usage();
    // // s32Ret = SAMPLE_AUDIO_AdecAo(&stAioAttr);/* read audio stream from file,decode and send AO*/
    // s32Ret =  SAMPLE_AUDIO_AiAencAdecAO(&stAioAttr);
    // // s32Ret = SAMPLE_AUDIO_AiAo(&stAioAttr);/* read audio stream from file,decode and send AO*/
    // if (HI_SUCCESS != s32Ret)
    // {
    //     printf("\nplay init failed\n");
    //     return HI_FAILURE;
    // }
    while(1){
        usleep(1000);
    }
    // while ((ch = getchar()) != 'q')
    // {
    //     switch (ch)
    //     {
    //         case '1':
    //         {
    //             s32Ret = SAMPLE_AUDIO_AiAenc(&stAioAttr);/* send audio frame to AENC channel form AI, save them*/
    //             break;
    //         }
    //         case '2':
    //         {
    //             s32Ret = SAMPLE_AUDIO_AdecAo(&stAioAttr);/* read audio stream from file,decode and send AO*/
    //             break;
    //         }
    //         case '3':
    //         {
    //             s32Ret = SAMPLE_AUDIO_AiAencAdecAO(&stAioAttr);/* read audio stream from file,decode and send AO*/
    //             break;
    //         }
    //         default:
    //         {
    //             SAMPLE_AUDIO_Usage();
    //             break;
    //         }
    //     }
    //     if (s32Ret != HI_SUCCESS)
    //     {
    //         break;
    //     }
    // }

    
    SAMPLE_COMM_SYS_Exit();

    return HI_SUCCESS;
}
