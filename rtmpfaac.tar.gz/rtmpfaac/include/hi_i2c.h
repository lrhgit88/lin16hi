#ifndef _HI_I2C_H
#define _HI_I2C_H

#ifdef __HuaweiLite__
#include <i2c.h>
#else
#include <linux/i2c-dev.h>
#endif

#endif
