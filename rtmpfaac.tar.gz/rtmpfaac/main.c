#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <limits.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>
#include <signal.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <netinet/in.h>
#include <pthread.h>
#include <stdbool.h>
#include "ringfifo.h"
#include "sample_comm.h"
#include "xiecc_rtmp.h"

// #include <unistd.h>
// #include <signal.h>
// #include <stdio.h>
// #include <stdlib.h>
#include <sys/param.h>
#include "faac.h"
#include "faaccfg.h"
// #include<sys/types.h>
// #include<sys/stat.h>
// #include<time.h>
//#include "librtmp_send264.h"
int g_s32Quit=0;
unsigned char * sps_pps_buffer;
/**************************************************************************************************
**
**
**
**************************************************************************************************/
extern void * SAMPLE_VENC_1080P_CLASSIC(void *p);
extern void *SAMPLE_VENC_NORMALP_CLASSIC(void *p);//lin
extern void *aacplayout(void *p);
extern int ringget_ai(struct ringbuf *getinfo);
void *audio(void *p);
uint32_t timeCount = 0;
uint32_t start_time =0;
void *prtmp=NULL;
struct ringbuf ringinfo;
struct ringbuf ringinfoa;
int ringbuflen=0;
// extern VENC_STREAM_S stStream;//lin

int SendH264Packet(unsigned char *data,unsigned int size,int bIsKeyFrame,unsigned int nTimeStamp);
void SendRtmpH264(void *data,int len,int key,unsigned int nTimeStamp)
{
	printf("len=%d\n",len);
	//SendH264Packet(data,len,key,nTimeStamp);
	rtmp_sender_write_video_frame(prtmp,data,len,nTimeStamp,key,start_time);
}
//rtmp 192.168.1.100
int main(int argc, char *argv[])
{  
	int s32MainFd,temp;
	struct timespec ts = { 2, 0 };
	pthread_t id;
	char serverStrBuf[100];
	sps_pps_buffer = malloc (400000);
	// init_daemon();
	 // signal(SIGINT, inlin());
	if(argc!=2)
	{
		printf("Usage: rtmp serverip -eg<< rtmp 192.168.1.100 >>");
		return -1;
	}
	// sprintf(serverStrBuf, "rtmp://%s/live/stream",argv[1]);
	sprintf(serverStrBuf, "%s",argv[1]);
	printf("Server=%s\n",serverStrBuf);
	void*prtmp = rtmp_sender_alloc(serverStrBuf); //return handle   rtmp_sender_alloc("rtmp://192.168.1.100/live/stream")
	if(rtmp_sender_start_publish(prtmp, 0, 0)!=0)
	{
		printf("connect %s fail\n",serverStrBuf);
		return -1;
	}
	ringmalloc(512*1024);//建立环形缓冲区
	start_time = RTMP_GetTime();
	/*
	线程1:main，初始化RTMP,创建SAMPLE_VENC_1080P_CLASSIC线程，usleep休眠，超时唤醒
	线程2:SAMPLE_VENC_1080P_CLASSIC,主要是初始化摄像头，然后sleep休眠，超时唤醒
	线程3:SAMPLE_COMM_VENC_GetVencStreamProc，获取H264视频数据，select休眠，超时或有数据唤醒
	*/
	pthread_create(&id,NULL,SAMPLE_VENC_NORMALP_CLASSIC,NULL);
	pthread_create(&id,NULL,audio,NULL);

	// pthread_create(&id,NULL,SAMPLE_VENC_1080P_CLASSIC,NULL);
	//SAMPLE_VENC_1080P_CLASSIC会将视频数据放到环形缓冲区ringinfo里
	while(1)
	{
		 ringbuflen = ringget(&ringinfo);
		if(ringbuflen !=0)
		{
			//printf("len=%d\n",ringbuflen);
			rtmp_sender_write_video_frame(prtmp,ringinfo.buffer, ringinfo.size,timeCount, 0,start_time);
			// timeCount += 2;
			timeCount = RTMP_GetTime();
		}   
		usleep(2000);
	}
	// 	while (!g_s32Quit)
	// {
	// 	nanosleep(&ts, NULL);
	// 	// EventLoop(s32MainFd);
	// }
	// if(g_s32Quit)
	// {
	// usleep(10);
	// ringfree();
	// printf("The Server quit!\n");
 //    }
	// faacEncClose(hEncoder);
    ringfree();
	 return 0;
}

HI_S32 HisiPutH264DataToRTMP(VENC_STREAM_S *pstStream)
{
	HI_S32 i,j;
	HI_S32 len=0,off=0,len2=2;
	
	int spslen=0;
	// printf("HisiPutH264DataToRTMP, enter, count: %d\n", pstStream->u32PackCount);
	int count = pstStream->u32PackCount;

	for (i = 0; i < count; i++)
	{
	// printf("stVStream.u32PackCount = %d, stVStream.pstPack[ ].DataType.enH264EType = %d\n",
	// 		pstStream->u32PackCount, pstStream->pstPack[i].DataType.enH264EType);
		if(pstStream->pstPack[0].DataType.enH264EType==0x07)
		{
			
			if (pstStream->pstPack[i].u32Len < 50) {
				// printf("HisiPutH264DataToRTMP, 1.2, data len: %d\n", pstStream->pstPack[i].u32Len);
				memcpy(sps_pps_buffer + spslen, pstStream->pstPack[i].pu8Addr, pstStream->pstPack[i].u32Len);
				spslen += pstStream->pstPack[i].u32Len;
				// timeCount = RTMP_GetTime();
			} else {
				// printf("HisiPutH264DataToRTMP, 1.2.1, data len: %d, spslen: %d, data %02x %02x %02x %02x %02x\n", 
				// 	pstStream->pstPack[i].u32Len, spslen, sps_pps_buffer[0], sps_pps_buffer[1], sps_pps_buffer[2],
				// 	sps_pps_buffer[3], sps_pps_buffer[4]);
				memcpy(sps_pps_buffer + spslen, pstStream->pstPack[i].pu8Addr, pstStream->pstPack[i].u32Len);
				rtmp_sender_write_video_frame(prtmp, sps_pps_buffer, pstStream->pstPack[i].u32Len+spslen, 
					timeCount, 0,start_time);
				spslen = 0;
				timeCount = RTMP_GetTime();
			}

			continue;
		}

		if(pstStream->pstPack[0].DataType.enH264EType==0x08)
		{
			// printf("HisiPutH264DataToRTMP, 1.3, data len: %d\n", pstStream->pstPack[i].u32Len+spslen);
			memcpy(sps_pps_buffer+spslen, pstStream->pstPack[i].pu8Addr, pstStream->pstPack[i].u32Len);
			// printfTrace ("put_frame, peekdata1, data %02x %02x %02x %02x %02x",
   //                      *((char*)channel->buf + sizeof(pjmedia_rtp_hdr)), 
   //                      *((char*)channel->buf + sizeof(pjmedia_rtp_hdr)+1), 
   //                      *((char*)channel->buf + sizeof(pjmedia_rtp_hdr) + 2), 
   //                      *((char*)channel->buf + sizeof(pjmedia_rtp_hdr) + 3), 
   //                      *((char*)channel->buf + sizeof(pjmedia_rtp_hdr) + 4));
			rtmp_sender_write_video_frame(prtmp, sps_pps_buffer, pstStream->pstPack[i].u32Len+spslen, 
					timeCount, 0,start_time);

			timeCount = RTMP_GetTime();
			continue;
		}
		// printf("HisiPutH264DataToRTMP, 1.1, data len: %d\n", pstStream->pstPack[i].u32Len);
		rtmp_sender_write_video_frame(prtmp, pstStream->pstPack[i].pu8Addr, pstStream->pstPack[i].u32Len, 
		timeCount, 0,start_time);
		timeCount = RTMP_GetTime();
	}	
	// printf("HisiPutH264DataToRTMP, exit\n");

	 return ;
}
void init_daemon()
{
int pid;
int i;
pid=fork();
if(pid<0)    
    exit(1);  //创建错误，退出
else if(pid>0) //父进程退出
    exit(0);
    
setsid(); //使子进程成为组长
pid=fork();
if(pid>0)
    exit(0); //再次退出，使进程不是组长，这样进程就不会打开控制终端
else if(pid<0)    
    exit(1);

//关闭进程打开的文件句柄
for(i=0;i<NOFILE;i++)
    close(i);
chdir("/root/test");  //改变目录
umask(0);//重设文件创建的掩码
// signal(SIGCHLD,SIG_IGN);
return;
}
void *audio(void *p)
{
 //    uint8_t *audio_buf_offset;
 //    uint32_t audio_len;
 //    uint8_t *p_audio;
 //    int ret = 0;
 //    printf("hisi rtmp, 1.1\n");


 //    ULONG nSampleRate = 8000;  // 采样率
 //    UINT nChannels = 1;         // 声道数
 //    UINT nBit = 16;             // 单样本位数
 //    ULONG nInputSamples = 0;	//输入样本数
 //    ULONG nMaxOutputBytes = 0;	//输出所需最大空间
	// ULONG nMaxInputBytes=0;     //输入最大字节
 //    faacEncHandle hEncoder;		//aac句柄
 //    faacEncConfigurationPtr pConfiguration;//aac设置指针 
 //    char* abuffer;
	// char* vbuffer;

 //    BYTE* pbAACBuffer;
 //    printf("hisi rtmp, 1.2\n");
 //  // (1) Open FAAC engine
 //    hEncoder = faacEncOpen(nSampleRate, nChannels, &nInputSamples, &nMaxOutputBytes);//初始化aac句柄，同时获取最大输入样本，及编码所需最小字节
	// nMaxInputBytes=nInputSamples*nBit/8;//计算最大输入字节,跟据最大输入样本数
	// printf("nInputSamples:%d nMaxInputBytes:%d nMaxOutputBytes:%d\n", nInputSamples, nMaxInputBytes,nMaxOutputBytes);
 //    if(hEncoder == NULL)
 //    {
 //        printf("[ERROR] Failed to call faacEncOpen()\n");
 //        return -1;
 //    }
 //    pbAACBuffer = (char*)malloc(nMaxOutputBytes);
 //    // (2.1) Get current encoding configuration
 //    pConfiguration = faacEncGetCurrentConfiguration(hEncoder);//获取配置结构指针
 //    pConfiguration->inputFormat = FAAC_INPUT_16BIT;
	// pConfiguration->outputFormat=1;
	// pConfiguration->useTns=true;
	// pConfiguration->useLfe=false;
	// pConfiguration->aacObjectType=LOW;
	// pConfiguration->mpegVersion = MPEG4; 
	// pConfiguration->shortctl=SHORTCTL_NORMAL;
	// pConfiguration->quantqual=60;
	// pConfiguration->bandWidth=80000;
	// pConfiguration->bitRate=0;
	// printf("!!!!!!!!!!!!!pConfiguration->outputFormat is %d\n",pConfiguration->outputFormat);
 //    // (2.2) Set encoding configuration
 //    ret = faacEncSetConfiguration(hEncoder, pConfiguration);//设置配置，根据不同设置，耗时不一样

 //   faacEncEncode(
 //        faacEncHandle hEncoder,
 //        int32_t * inputBuffer,       //pcm输入buffer， pbPCMBuffer 
 //        unsigned int samplesInput,   //一次输入的样本数（注意不是数据长度 ），samplesInput
 //        unsigned char *outputBuffer, //AAC输出buffer， pbAACBuffer 
 //        unsigned int bufferSize);
 //   faacEncClose(faacEncHandle hEncoder);
	typedef unsigned char   BYTE;
 
	// unsigned long	nSampleRate = 44100;
	unsigned long	nSampleRate = 8000;
	unsigned int	nChannels = 1;
	unsigned int	nPCMBitSize = 16;
	unsigned long	nInputSamples = 0;
	unsigned long	nMaxOutputBytes = 0;
	faacEncHandle	hEncoder = {0};
 
	// 设置输入输出文件
	// FILE* fpIn = fopen("Beyond.pcm", "rb");
	// FILE* fpOut = fopen("Beyond.aac", "wb");
 
	// if(fpIn==NULL || fpOut==NULL)
	// {
	// 	printf("faac wenjian Failed!!\n");
	// 	return -1;
	// }
 
	// 打开faac编码器引擎
	hEncoder = faacEncOpen(nSampleRate, nChannels, &nInputSamples, &nMaxOutputBytes);
	if(hEncoder == NULL)
	{
		printf("faac Failed!\n");
		return -1;
	}
 
	// 分配内存信息
	int		nPCMBufferSize = nInputSamples*nPCMBitSize/8;
	BYTE*	pbPCMBuffer = (uint8_t*)malloc(nPCMBufferSize);//new BYTE[nPCMBufferSize];
	BYTE*	pbAACBuffer = (uint8_t*)malloc(nMaxOutputBytes);//new BYTE*[nMaxOutputBytes];
 
	// 获取当前编码器信息
	faacEncConfigurationPtr pConfiguration = {0};
	pConfiguration = faacEncGetCurrentConfiguration(hEncoder);
 
	// 设置编码配置信息
	/*
		PCM Sample Input Format
		0	FAAC_INPUT_NULL			invalid, signifies a misconfigured config
		1	FAAC_INPUT_16BIT		native endian 16bit
		2	FAAC_INPUT_24BIT		native endian 24bit in 24 bits		(not implemented)
		3	FAAC_INPUT_32BIT		native endian 24bit in 32 bits		(DEFAULT)
		4	FAAC_INPUT_FLOAT		32bit floating point
    */
	pConfiguration->inputFormat = FAAC_INPUT_16BIT;
 
	// 0 = Raw; 1 = ADTS
	pConfiguration->outputFormat = 1;
 
	// AAC object types 
	//#define MAIN 1
	//#define LOW  2
	//#define SSR  3
	//#define LTP  4
	pConfiguration->aacObjectType = LOW;
	pConfiguration->allowMidside = 0;
	pConfiguration->useLfe = 0;
	pConfiguration->bitRate = 48000;
	pConfiguration->bandWidth = 32000;
 
	// 其他的参数不知道怎么配置，毕竟对音频不熟
	// 不过当前的设置可以实现转换，不过声音好像有一丢丢怪异
	// 这一块的配置信息很重要，错了会导致转码失败，然后你以为代码其他地方错了
 
	// 重置编码器的配置信息
	faacEncSetConfiguration(hEncoder, pConfiguration);
 
	size_t nRet = 0;
 
	printf("数据转换中:        ");
	int i = 0;
	// while( (nRet = fread(pbPCMBuffer, 1, nPCMBufferSize, fpIn)) > 0)
	// {
	// 	printf("\b\b\b\b\b\b\b\b%-8d", ++i);
	// 	nInputSamples = nRet / (nPCMBitSize/8);
 
	// 	// 编码
	// 	nRet = faacEncEncode(hEncoder, (int*) pbPCMBuffer, nInputSamples, pbAACBuffer, nMaxOutputBytes);
 
	// 	// 写入转码后的数据
	// 	fwrite(pbAACBuffer, 1, nRet, fpOut);
	// }
	while(1){
	nRet = ringget_ai(&ringinfoa);
	nInputSamples = nRet / (nPCMBitSize/8);
    memcpy(pbPCMBuffer, &ringinfoa, nRet);
    nRet = faacEncEncode(hEncoder, (int*) pbPCMBuffer, nInputSamples, pbAACBuffer, nMaxOutputBytes);
    timeCount = RTMP_GetTime();
    rtmp_sender_write_audio_frame(prtmp,pbAACBuffer,nRet,timeCount,start_time);
    printf("\nok\n");
    usleep(1000);
    }
	// 扫尾工作
	 faacEncClose(hEncoder);

	// fclose(fpOut);
	// fclose(fpIn);
 
	// delete[] pbAACBuffer;
	// delete[] pbPCMBuffer;
	return 0;
}