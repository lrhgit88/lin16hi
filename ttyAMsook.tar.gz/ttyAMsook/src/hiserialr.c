/************************************************************************************************
*****Describe: This program is writen to operate HI35xx serial devices.                     *****
*****Email: lishuangliang@outlook.com                                              			*****
*****Author: shuang liang li																*****
*****Date: 2018-09-30																		*****
*************************************************************************************************/

#include <stdio.h>       
#include <stdlib.h>     
#include <unistd.h>    
#include <sys/types.h>   
#include <sys/stat.h>     
#include <fcntl.h>     
#include <termios.h>    
#include <errno.h>      
#include <string.h> 
#include <signal.h>
// #include <pthread.h>
#include <pthread.h>
//宏定义  
#define HI_FALSE  -1  
#define HI_TRUE     0   

#ifdef debugprintf
	#define debugpri(mesg, args...) fprintf(stderr, "[HI Serial print:%s:%d:] " mesg "\n", __FILE__, __LINE__, ##args) 
#else
	#define debugpri(mesg, args...)
#endif

int HiSerfd; 
void HI_Serial_Close(int fd);
void *threadSendbuf(void *);
long hexToDec(char *source);
// int dimmer(int a);
 unsigned char value[] = 
 {
  0xFF,0xAA,0x19,0x00,0x01,0x01,0xC4,0x0D,0x0A,\
  0xFF,0xAA,0x19,0x00,0x0A,0x01,0xCD,0x0D,0x0A,\
  0xFF,0xAA,0x19,0x00,0x14,0x01,0xD7,0x0D,0x0A,\
  0xFF,0xAA,0x19,0x00,0x1E,0x01,0xE1,0x0D,0x0A,\
  0xFF,0xAA,0x19,0x00,0x28,0x01,0xEB,0x0D,0x0A,\
  0xFF,0xAA,0x19,0x00,0x32,0x01,0xF5,0x0D,0x0A,\
  0xFF,0xAA,0x19,0x00,0x3C,0x01,0xFF,0x0D,0x0A,\
  0xFF,0xAA,0x19,0x00,0x46,0x01,0x09,0x0D,0x0A,\
  0xFF,0xAA,0x19,0x00,0x50,0x01,0x13,0x0D,0x0A,\
  0xFF,0xAA,0x19,0x00,0x5A,0x01,0x1D,0x0D,0x0A
};

 unsigned char valuetemp[9] = {0}; 

// int valueIdx = 0;
  
void Hi_sigsegv(int dummy)
{
	if(HiSerfd > 0)
		HI_Serial_Close(HiSerfd);
	fprintf(stderr, "Hi Serial Caught SIGSEGV, Abort!\n");
	fclose(stderr);
	abort();
}


void Hi_sigterm(int dummy)
{
	if(HiSerfd > 0)
		HI_Serial_Close(HiSerfd);
	fprintf(stderr, "Hi Serial Caught SIGTERM, Abort!\n");
	fclose(stderr);
	exit(0);
}

void Hi_init_signals(void)
{
	struct sigaction sa;
	sa.sa_flags = 0;
	
	sigemptyset(&sa.sa_mask);
	sigaddset(&sa.sa_mask, SIGSEGV);
	sigaddset(&sa.sa_mask, SIGTERM);
	sigaddset(&sa.sa_mask, SIGPIPE);
	
	sa.sa_handler = Hi_sigsegv;
	sigaction(SIGSEGV, &sa, NULL);

	sa.sa_handler = Hi_sigterm;
	sigaction(SIGTERM, &sa, NULL);

	sa.sa_handler = SIG_IGN;
	sigaction(SIGPIPE, &sa, NULL);
}

int HI_Serial_Usage(void)
{
    printf("Usage:\n");
    printf("\tmyhicom [-d] <HiSerialDevice> [-s] get netdeviece info [-rw] read or wite select\n");
    printf("\tmyhicom [-h] for more usage\n");
    printf("\tmyhicom [-v] the verson of the sofware\n");
	printf("\tExample:\n\tmyhicom -d /dev/ttyAMA1 -s 115200 -w HiSerial:HelloWorld\n");
}

/*
*Function: HI_Serial_Open(int fd,char* ComDevice)  
*Param: fd:file descirbe handle	 Serial Device: /dev/ttyAMA1 /dev/ttyAMA2
*Output: Ok or Fail
*/

int HI_Serial_Open(char* HiSerDevice)  
{  
    int fd;
		
	fd = open(HiSerDevice, O_RDWR|O_NOCTTY|O_NDELAY);  
	if (HI_FALSE == fd)  
	{  
		perror("HiSerial Can't Open Serial HiSerDevice");  
		return(HI_FALSE);  
	}  
	//恢复串口为阻塞状态                                 
	if(fcntl(fd, F_SETFL, 0) < 0)  
	{  
		debugpri("fcntl failed!\n");  
		return(HI_FALSE);  
	}       
	else  
	{  
		debugpri("fcntl=%d\n",fcntl(fd, F_SETFL,0));  
	}  
	//测试是否为终端设备      
	if(0 == isatty(STDIN_FILENO))  
	{  
		debugpri("standard input is not a terminal device\n");  
		return(HI_FALSE);  
	}  
	else  
	{  
		debugpri("isatty success!\n");  
	}                
	printf("fd->open=%d\n",fd);  
	return fd;  
}  

/*
*Function: HI_Serial_Close(int fd) 
*Param: fd:file descirbe handle	 
*Output: Null
*/

void HI_Serial_Close(int fd)  
{  
	if(fd > 0)
		close(fd); 
	return;	
}  

/*
*Function: HI_Serial_Set(int fd,int speed,int flow_ctrl,int databits,int stopbits,int parity) 
*Param1: fd: file descirbe handle	 
*Param2: speed: select the Serial speed.115200,19200,9600...
*Param3: flow_ctrl: if use flow control
*Param4: databits: data bit select
*Param5: stopbits: stopbits select	
*Param5: parity: partiy select	
*Output: Ok or Fail
*/
int HI_Serial_Set(int fd,int speed,int flow_ctrl,int databits,int stopbits,int parity)  
{  
     
	int   i;  
	// int   status;  
	int   speed_arr[] = { B115200, B19200, B9600, B4800, B2400, B1200, B300};  
	int   name_arr[] = {115200,  19200,  9600,  4800,  2400,  1200,  300};  
           
	struct termios options;  
     

	if( tcgetattr( fd,&options)  !=  0)  
	{  
		perror("SetupSerial 1");      
		return(HI_FALSE);   
	}  
    
    //set buater rate 
	for ( i= 0;  i < sizeof(speed_arr) / sizeof(int);  i++)  
	{  
		if  (speed == name_arr[i])  
		{               
			cfsetispeed(&options, speed_arr[i]);   
			cfsetospeed(&options, speed_arr[i]);    
		}  
	}       
     
    //set control model 
    options.c_cflag |= CLOCAL;  
    options.c_cflag |= CREAD;  
    
    //set flow control
    switch(flow_ctrl)  
    {  
        
		case 0 ://none  
              options.c_cflag &= ~CRTSCTS;  
              break;     
        
		case 1 ://use hard ware 
              options.c_cflag |= CRTSCTS;  
              break;  
		case 2 ://use sofware
              options.c_cflag |= IXON | IXOFF | IXANY;  
              break;  
    }  
  
    //select data bit   
    options.c_cflag &= ~CSIZE;  
    switch (databits)  
    {    
		case 5    :  
                     options.c_cflag |= CS5;  
                     break;  
		case 6    :  
                     options.c_cflag |= CS6;  
                     break;  
		case 7    :      
                 options.c_cflag |= CS7;  
                 break;  
		case 8:      
                 options.c_cflag |= CS8;  
                 break;    
		default:     
                 fprintf(stderr,"Unsupported data size\n");  
                 return (HI_FALSE);   
    }  
    //select parity bit 
    switch (parity)  
    {    
		case 'n':  
		case 'N':  
                 options.c_cflag &= ~PARENB;   
                 options.c_iflag &= ~INPCK;      
                 break;   
		case 'o':    
		case 'O':    
                 options.c_cflag |= (PARODD | PARENB);   
                 options.c_iflag |= INPCK;               
                 break;   
		case 'e':   
		case 'E':  
                 options.c_cflag |= PARENB;         
                 options.c_cflag &= ~PARODD;         
                 options.c_iflag |= INPCK;        
                 break;  
		case 's':  
		case 'S':    
                 options.c_cflag &= ~PARENB;  
                 options.c_cflag &= ~CSTOPB;  
                 break;   
        default:    
                 fprintf(stderr,"Unsupported parity\n");      
                 return (HI_FALSE);   
    }   
    // set stopbit  
    switch (stopbits)  
    {    
		case 1:     
                 options.c_cflag &= ~CSTOPB; break;   
		case 2:     
                 options.c_cflag |= CSTOPB; break;  
		default:     
                       fprintf(stderr,"Unsupported stop bits\n");   
                       return (HI_FALSE);  
    }  
     
	//set raw data output 
	options.c_oflag &= ~OPOST;  
    
	options.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);  
	//options.c_lflag &= ~(ISIG | ICANON);  
     
    //set wait time  
    options.c_cc[VTIME] = 1;    
    options.c_cc[VMIN] = 1; 
     
  
    tcflush(fd,TCIFLUSH);  
     
    //set the attribute to HiSerial device 
    if (tcsetattr(fd,TCSANOW,&options) != 0)    
	{  
		perror("com set error!\n");    
		return (HI_FALSE);   
	}  
    return (HI_TRUE);   
}  

/*
*Function: HI_Serial_Init(int fd, int speed,int flow_ctrl,int databits,int stopbits,int parity)  
*Param: ...
*Output: HI_TRUE or HI_FALSE
*/
int HI_Serial_Init(int fd, int speed,int flow_ctrl,int databits,int stopbits,int parity)  
{  
    // int err;  
    //设置串口数据帧格式  
    if (HI_Serial_Set(fd,speed,flow_ctrl,databits,stopbits,parity) == HI_FALSE)  
	{                                                           
		return HI_FALSE;  
	}  
    else  
	{  
		return  HI_TRUE;  
	}  
}  

/*
*Function: HI_Serial_Send(int fd, char *send_buf,int data_len)
*Param1: fd:file descirbe handle	
*Param2: send_buf:Data to be send
*Param2: data_len:Data len
*Output: Data send len or HI_FALSE
*/
int HI_Serial_Send(int fd, const void *send_buf,int data_len)  
{  
    int len = 0;  
     
    len = write(fd,send_buf,data_len);  
    if (len == data_len )  
	{  
		debugpri("send data is %s\n",send_buf);
		return len;  
	}       
    else     
	{                   
		tcflush(fd,TCOFLUSH);  
		return HI_FALSE;  
	}  
     
} 

/*
*Function:  HI_Serial_Recv(int fd, char *rcv_buf,int data_len) 
*Param1: fd:file descirbe handle	
*Param2: rcv_buf:receive Data 
*Param2: data_len:receive Data  len
*Output: Receive Data len or HI_FALSE
*/
int HI_Serial_Recv(int fd, char *rcv_buf,int data_len)  
{  
	int len,fs_sel;  
    fd_set fs_read;  
     
    struct timeval time;  
     
    FD_ZERO(&fs_read);  
    FD_SET(fd,&fs_read);  
     
    time.tv_sec = 30;  
    time.tv_usec = 0;  
     
    //select fdset
    fs_sel = select(fd+1,&fs_read,NULL,NULL,&time);  
    if(fs_sel)  
	{  
		len = read(fd,rcv_buf,data_len);  
		debugpri("HiSeral Receive Data = %s len = %d fs_sel = %d\n",rcv_buf,len,fs_sel);  
		return len;  
	}  
    else  
	{  
		debugpri("Hiserial haven't data receive!");  
		return HI_FALSE;  
	}       
} 
unsigned char recvbuf[2]={0};
unsigned char sendbuf[1024]={0};
unsigned char valueIdx=0;
// char* valueIdx;

int main ( int argc, char *argv[] )
{
	int cmd;
	extern char *optarg;
	serial_init();
	// // int len=0;
	// // pthread_t id, id1;
 //    //extern char *optarg;
 //    //extern int optind, opterr, optopt;
	// char HiSerialDev[32]="/dev/ttyAMA2";
	// // unsigned char sendbuf[1024]={0};
	// // unsigned char recvbuf[2]={0};
	// int SerialSpeed =115200;
	// // unsigned int valueIdx=0;
	// Hi_init_signals();

	//  debugpri("myHicom read\n");
	//  HiSerfd = HI_Serial_Open(HiSerialDev);
	//  HI_Serial_Init(HiSerfd,SerialSpeed,0,8,1,'N');

     memcpy(valuetemp,value,9);
     	if(argc == 1)
	{
		HI_Serial_Usage();		
		exit(0);
	}
	else
	{
		while ((cmd = getopt(argc, argv, "ht:la")) != -1)
		{
			switch (cmd)
			{
					case 'h':
					HI_Serial_Usage();
					break;
					case 't':
					 valueIdx=(*optarg-0x30);
					printf("input data:%x\n",valueIdx);
					dimmer(valueIdx);
					case 'l':
					brightness();
					break;
					case 'a':
					// while(1)
					// {
					//  key();
					//  usleep(200000);
					// }
					key();
					break;
					default:
					exit(0);
			 }
		}	
	}	
	return 0;
}
//
int serial_init()
{
	char HiSerialDev[32]="/dev/ttyAMA2";
	int SerialSpeed =115200;
	Hi_init_signals();
	HiSerfd = HI_Serial_Open(HiSerialDev);
	HI_Serial_Init(HiSerfd,SerialSpeed,0,8,1,'N');
	printf("init Ok\n");
	return 0;
}
//
int dimmer(valueIdx)
{
unsigned char len=0;
unsigned char k=0;
unsigned char rebuf[1] = {0}; 
k=valueIdx;
if (k > 8)
{
	k = 0;
}
memset(valuetemp,0,sizeof(valuetemp));
memcpy(valuetemp,value + 9*k,9);
// HI_Serial_Send(HiSerfd, &valuetemp, 9);
// valueIdx ++;
// if (valueIdx > 8)
// {
// 	valueIdx = 0;
// }
// sleep(1);
while(1)
{

HI_Serial_Send(HiSerfd, &valuetemp, 9);
usleep(100000);
len = HI_Serial_Recv(HiSerfd, recvbuf,sizeof(recvbuf)); 
	if(len==1) 
	{
		if(recvbuf[0] != 0x32)
		{
            // unsigned char rebuf[1] = {0}; 
    		memcpy(rebuf,recvbuf,1);
			printf("Hiserial receive data:%x\n",rebuf[0]);
			memset(recvbuf,0,sizeof(recvbuf));
			return (int)rebuf[0];
		}
	}
		else
	{
      // HI_Serial_Send(HiSerfd, &valuetemp, 9);
      // usleep(200000);
      // nkey=1;
      break;
	}
// r
}
printf("return data:%x\n",rebuf[0]);
return (int)rebuf[0];
}

int brightness()
{
unsigned char len=0;
unsigned char valueg[] = {0xFF,0xAA,0x21,0xFF,0xFF,0x01,0xC9,0x0D,0x0A};
unsigned char g_rebuf[2] = {0}; 
// valueIdx=a;
memset(valuetemp,0,sizeof(valuetemp));
memcpy(valuetemp,valueg,9);
HI_Serial_Send(HiSerfd, &valuetemp, 9);
usleep(100000);
memset(valuetemp,0,sizeof(valuetemp));
len = HI_Serial_Recv(HiSerfd, recvbuf,sizeof(recvbuf)); 
	if(len==2) 
	{
		if(recvbuf[0] != 0x32)
		{
             // unsigned char g_rebuf[2] = {0}; 
             memset(g_rebuf,0,sizeof(g_rebuf));
             memcpy(g_rebuf,recvbuf,2);
             printf("Hiserial receive data:%x %x\n",g_rebuf[1],g_rebuf[0]);
             memset(recvbuf,0,sizeof(recvbuf));
		}
	}
int lvalue;
lvalue=((g_rebuf[1]&0xFF)<<8)|(g_rebuf[0]&0xFF);
printf("return data:%x\n",lvalue);
return lvalue;
}
//
int key()
{
	//nkey=1;
unsigned char len=0;
unsigned char valuek[] = {0xFF,0xAA,0x22,0xFF,0xFF,0x01,0xCA,0x0D,0x0A};
unsigned char g_rebuf[1] = {0}; 
int lvalue;
// valueIdx=a;
memset(valuetemp,0,sizeof(valuetemp));
memcpy(valuetemp,valuek,9);
while(1)
  {
 // printf("len:%x\n",len);
 memset(g_rebuf,0,sizeof(g_rebuf));
 HI_Serial_Send(HiSerfd, &valuetemp, 9);
 usleep(200000);
 // memset(valuetemp,0,sizeof(valuetemp));
 len = HI_Serial_Recv(HiSerfd, recvbuf,sizeof(recvbuf)); 
 printf("len:%x\n",len);
	if(len==1)
	{
		if((recvbuf[0] != 0x32)&&(recvbuf[0] != 0x0)) 
		{
             // unsigned char g_rebuf[2] = {0}; 
             memset(g_rebuf,0,sizeof(g_rebuf));
             memcpy(g_rebuf,recvbuf,1);
             printf("Hiserial receive data:%x\n",g_rebuf[0]);
             memset(recvbuf,0,sizeof(recvbuf));
             lvalue=0;
	         lvalue=g_rebuf[0];
	         printf("return datawout:%x\n",lvalue);
	          return lvalue;
		}
	}
	else
	{
      HI_Serial_Send(HiSerfd, &valuetemp, 9);
      usleep(200000);
      // nkey=1;
      break;
	}
	lvalue=0;
	lvalue=g_rebuf[0];
	memset(g_rebuf,0,sizeof(g_rebuf));
	printf("return datawin:%x\n",lvalue);
	// nkey=0;
	// return lvalue;
  }
// return lvalue;
// printf("return datawoutkk:%x\n",lvalue);
  memset(valuetemp,0,sizeof(valuetemp));
  return lvalue;
 }
//
void *threadSendbuf(void *t)
{
	// char HiSerialDev[32]="/dev/ttyAMA2";
	// char sendbuf[1024]={0};
	//0~8
	// unsigned char value[] = {0xFF,0xAA,0x19,0x00,0x5A,0x01,0x1D,0x0D,0x0A};
	unsigned char valueg[] = {0xFF,0xAA,0x21,0xFF,0xFF,0x01,0xC9,0x0D,0x0A};

    
	// unsigned char value[] = {0xFF ,0xAA ,0x19 ,0x00 ,0x0A ,0x01 ,0xCD ,0x0D ,0x0A,0xFF ,0xAA ,0x19 ,0x00 ,0x14 ,0x01 ,0xD7 ,0x0D ,0x0A ,0xFF ,0xAA ,0x19 ,0x00 ,0x1E ,0x01 ,0xE1 ,0x0D ,0x0A ,0xFF ,0xAA ,0x19 ,0x00 ,0x28 ,0x01 ,0xEB ,0x0D ,0x0A ,0xFF ,0xAA ,0x19 ,0x00 ,0x32 ,0x01 ,0xF5 ,0x0D ,0x0A ,0xFF ,0xAA ,0x19 ,0x00 ,0x3C ,0x01 ,0xFF ,0x0D ,0x0A ,0xFF ,0xAA ,0x19 ,0x00 ,0x46 ,0x01 ,0x09 ,0x0D ,0x0A ,0xFF ,0xAA ,0x19 ,0x00 ,0x50 ,0x01 ,0x13 ,0x0D ,0x0A,0xFF ,0xAA ,0x19 ,0x00 ,0x5A ,0x01 ,0x1D ,0x0D ,0x0A};
    unsigned char valuetemp[9] = {0}; 
    memcpy(valuetemp,valueg,9);
    HI_Serial_Send(HiSerfd, &valuetemp, 9);
    sleep(1);
    memset(valuetemp,0,sizeof(valuetemp));	
}

 
/* 返回ch字符在sign数组中的序号 */
int getIndexOfSigns(char ch)
{
    if(ch >= '0' && ch <= '9')
    {
        return ch - '0';
    }
    if(ch >= 'A' && ch <='F') 
    {
        return ch - 'A' + 10;
    }
    if(ch >= 'a' && ch <= 'f')
    {
        return ch - 'a' + 10;
    }
    return -1;
}
/* 十六进制数转换为十进制数 */
long hexToDec(char *source)
{
    long sum = 0;
    long t = 1;
    int i, len;
 
    len = strlen(source);
    for(i=len-1; i>=0; i--)
    {
        sum += t * getIndexOfSigns(*(source + i));
        t *= 16;
    }  
 
    return sum;
}
