himm 0x1203000c 0xac;
himm 0x100d0004 0x1;
#power on sd controller
himm 0x1209802c 0x17;
#turn on WL_REG_ON
himm 0x12098034 0x10101070;
himm 0x120400d0 0x1;
himm 0x120400d4 0x1;
himm 0x120400d8 0x1;
himm 0x120400dc 0x1;
himm 0x120400e0 0x1;
himm 0x120400e4 0x1;
himm 0x120400e8 0x1;
himm 0x120400ec 0x1;
himm 0x120400f0 0x1;
himm 0x12040038 0x0;

insmod  cfg80211.ko
insmod bcmdhd.ko firmware_path=/etc/firmware/fw_bcm43455c0_ag_apsta.bin nvram_path=/etc/firmware/nvram_ap6255.txt dhd_oob_gpio_num=116 sdio_slot=2;

#turn off WL_REG_ON then turn on
himm 0x12098034 0x10101050;
himm 0x12098034 0x10101070;

ifconfig wlan0 up;

#connect AP with OPEN
wl down;
wl ap 0;
wl sup_wpa 1;
wl auth 0;
wl wsec 0;
wl wpa_auth 0;
wl up;
wl ssid hisiap;
sleep 2
udhcpc -i wlan0;
