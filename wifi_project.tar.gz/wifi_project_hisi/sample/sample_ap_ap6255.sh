himm 0x1203000c 0xac;
himm 0x100d0004 0x1;
#power on sd controller
himm 0x1209802c 0x17;
#turn on WL_REG_ON
himm 0x12098034 0x10101070;
himm 0x120400d0 0x1;
himm 0x120400d4 0x1;
himm 0x120400d8 0x1;
himm 0x120400dc 0x1;
himm 0x120400e0 0x1;
himm 0x120400e4 0x1;
himm 0x120400e8 0x1;
himm 0x120400ec 0x1;
himm 0x120400f0 0x1;
himm 0x12040038 0x0;

insmod  cfg80211.ko
insmod bcmdhd.ko firmware_path=/etc/firmware/fw_bcm43455c0_ag_apsta.bin nvram_path=/etc/firmware/nvram_ap6255.txt dhd_oob_gpio_num=116 sdio_slot=2;

#turn off WL_REG_ON then turn on again
himm 0x12098034 0x10101050;
himm 0x12098034 0x10101070;

ifconfig wlan0 up;

wl down
wl apsta 0
wl ap 1
# 2.4G channel, set to 1 ~ 13
# 5G channel, set as bellow
wl chanspec 149/80

# For WPA2-PSK 
#wl auth 0
#wl set_pmk 12345678
#wl wpa_auth 128
#wl wsec 4

wl up
wl ssid hisiap
ifconfig wlan0 192.168.1.1
busybox udhcpd -fS /etc/Wireless/udhcpd.conf &
