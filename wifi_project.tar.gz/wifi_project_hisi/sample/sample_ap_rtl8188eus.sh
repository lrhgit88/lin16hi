#!/bin/sh

insmod cfg80211.ko
insmod 8188eu.ko

hostapd -e /etc/Wireless/entropy.bin /etc/Wireless/hostapd_wpa.conf &

sleep 2
ifconfig wlan0 192.168.1.1
busybox udhcpd -fS /etc/Wireless/udhcpd.conf &
