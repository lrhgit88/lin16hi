#!/bin/sh

insmod cfg80211.ko
insmod 8188eu.ko

wpa_supplicant -iwlan0 -Dnl80211 -c/etc/Wireless/wpa_supplicant.conf &

wpa_cli -iwlan0 -p/var/wpa_supplicant
