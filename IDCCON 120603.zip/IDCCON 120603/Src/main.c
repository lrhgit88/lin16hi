/**
******************************************************************************
* File Name          : main.c
* Description        : Main program body
******************************************************************************
** This notice applies to any and all portions of this file
* that are not between comment pairs USER CODE BEGIN and
* USER CODE END. Other portions of this file, whether 
* inserted by the user or by software development tools
* are owned by their respective copyright owners.
*
* COPYRIGHT(c) 2017 STMicroelectronics
*
* Redistribution and use in source and binary forms, with or without modification,
* are permitted provided that the following conditions are met:
*   1. Redistributions of source code must retain the above copyright notice,
*      this list of conditions and the following disclaimer.
*   2. Redistributions in binary form must reproduce the above copyright notice,
*      this list of conditions and the following disclaimer in the documentation
*      and/or other materials provided with the distribution.
*   3. Neither the name of STMicroelectronics nor the names of its contributors
*      may be used to endorse or promote products derived from this software
*      without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
* FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
		   * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
* OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*
******************************************************************************
*/
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f0xx_hal.h"
#include "delay.h"
#include "usart.h"
#include "xieyi.h"
#include "PWMT.h"	
#include <string.h>

/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc;

CRC_HandleTypeDef hcrc;

IWDG_HandleTypeDef hiwdg;

UART_HandleTypeDef huart1;

WWDG_HandleTypeDef hwwdg;

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/
const uint16_t  FCCW[4]={0x0900,0x0A00,0x0600,0x0500};//��ת
const uint16_t  FCW[4]={0x0500,0x0600,0x0A00,0x0900};//��ת
const uint16_t  ZBCCW[4]={0x0002,0x0002,0x0001,0x0001};//��ת
const uint16_t  ZBCW[4]={0x0001,0x0001,0x0002,0x0002};//��ת
const uint16_t  ZACCW[4]={0x0080,0x0040,0x0040,0x0080};//��ת
const uint16_t  ZACW[4]={0x0080,0x0040,0x0040,0x0080};//��ת
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC_Init(void);
static void MX_CRC_Init(void);
static void MX_IWDG_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_WWDG_Init(void);
//extern static void MX_TIM3_Init(void);
void Fmotor_cw(uint16_t N);
void Fmotor_ccw(uint16_t N);
void Zmotor_cw(uint16_t N);
void Zmotor_ccw(uint16_t N);
void Fmotor_stop(uint16_t N);
void Zmotor_stop(uint16_t N);
protocolHead_t *tthead;
uint16_t TD;
uint16_t F;

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/

/* USER CODE END PFP */

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

int main(void)
{
  uint8_t len;
  uint16_t nbu=0;
	uint16_t hbu=0;
  TD=50 ;
  F=10000 ;
	/* USER CODE BEGIN 1 */

	/* USER CODE END 1 */

	/* MCU Configuration----------------------------------------------------------*/

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();

	/* USER CODE BEGIN Init */

	/* USER CODE END Init */

	/* Configure the system clock */
	SystemClock_Config();
	delay_init(48);

	/* USER CODE BEGIN SysInit */

	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */
	MX_GPIO_Init();
	MX_ADC_Init();
	MX_CRC_Init();
	MX_IWDG_Init();
	MX_TIM3_Init();
	MX_USART1_UART_Init();
	//MX_WWDG_Init();

	/* USER CODE BEGIN 2 */

	/* USER CODE END 2 */

	/* Infinite loop */
	/* USER CODE BEGIN WHILE */
	while (1)
	{  
		Zmotor_stop(2);
		Fmotor_stop(2);
		//USART_RX_STA=0;
		//HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_15);

		if(USART_RX_STA&0x8000)
		{					   
			len=USART_RX_STA&0x3fff;//
			if(gizProtocolGetOnePacket(USART_RX_BUF, tthead, len)==0)
			{
			tthead=0;
			//HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_15);	
			tthead = (protocolHead_t *)USART_RX_BUF;
			//USART_RX_BUF=0;
			//USART_RX_STA=0;
			//USART_RX_BUF=0;
				if(tthead->head[0]==0xff)
				{  
					if(tthead->head[1]==0xaa)
					{
						switch(tthead->cmd)
						{
							case CMD_Motorforward_f:
								hbu=((uint16_t)tthead->data[0])&0x00ff;
								nbu=((uint16_t)tthead->data[1])|(hbu<<8);
								Fmotor_cw(nbu);
							  printf("88");
								break;
							case CMD_Motorreverses_f:
								hbu=((uint16_t)tthead->data[0])&0x00ff;
								nbu=((uint16_t)tthead->data[1])|(hbu<<8);
								Fmotor_ccw(nbu);
							  printf("88");
								break;
							case CMD_Motorforward_z:
								hbu=((uint16_t)tthead->data[0])&0x00ff;
								nbu=((uint16_t)tthead->data[1])|(hbu<<8);
							  if(nbu>=0xff80)	
								{
								Fmotor_stop(2);
								}
								else
								{	
								Zmotor_cw(nbu);
								printf("88");
								}
								break;
							case CMD_Motorreverses_z:
								hbu=((uint16_t)tthead->data[0])&0x00ff;
								nbu=((uint16_t)tthead->data[1])|(hbu<<8);
								Zmotor_ccw(nbu);
							  printf("88");
								break;
							case CMD_Motorstop_Z:
								hbu=((uint16_t)tthead->data[0])&0x00ff;
								nbu=((uint16_t)tthead->data[1])|(hbu<<8);
								if(nbu==0xffff)	
								{
								Zmotor_stop(2);
								printf("88");
								}
								break;
							case CMD_Motorstop_F:
								hbu=((uint16_t)tthead->data[0])&0x00ff;
								nbu=((uint16_t)tthead->data[1])|(hbu<<8);
								if(nbu==0xffff)	
								{
								Fmotor_stop(2);
								printf("88");
								}
								break;
							case CMD_SOFTWARE_VERSION:
								hbu=((uint16_t)tthead->data[0])&0x00ff;
								nbu=((uint16_t)tthead->data[1])|(hbu<<8);
								if(nbu==0xffff)	
								{
									printf("01");
								}
								break;
							case CMD_TD:
								hbu=((uint16_t)tthead->data[0])&0x00ff;
								TD=((uint16_t)tthead->data[1])|(hbu<<8);
							 // F=10000 ;
							  MX_TIM3_Init();
								//Fmotor_ccw(nbu);
							  printf("88");
								break;
							case CMD_TF:
								hbu=((uint16_t)tthead->data[0])&0x00ff;
								F=((uint16_t)tthead->data[1])|(hbu<<8);
							  //TD=50;
							  MX_TIM3_Init();
								//Fmotor_ccw(nbu);
							  printf("88");
								break;
							default:
								//printf("42");
								break;
						}
				  }
				}
				if(HAL_IWDG_Refresh(&hiwdg)==HAL_OK )
			{
			 HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_15);
			}
			//	printf("88");
				//HAL_IWDG_Refresh(&hiwdg);
			  //USART_RX_BUF=0;
				USART_RX_STA=0;
		}
	}
		HAL_IWDG_Refresh(&hiwdg);
}
	/* USER CODE END 3 */

}

/** System Clock Configuration
*/
void SystemClock_Config(void)
{

	RCC_OscInitTypeDef RCC_OscInitStruct;
	RCC_ClkInitTypeDef RCC_ClkInitStruct;
	RCC_PeriphCLKInitTypeDef PeriphClkInit;

    /**Initializes the CPU, AHB and APB busses clocks 
    */
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI14|RCC_OSCILLATORTYPE_LSI
									   |RCC_OSCILLATORTYPE_HSE;
	RCC_OscInitStruct.HSEState = RCC_HSE_ON;
	RCC_OscInitStruct.HSIState = RCC_HSI_ON;
	RCC_OscInitStruct.HSI14State = RCC_HSI14_ON;
	RCC_OscInitStruct.HSI14CalibrationValue = 16;
	RCC_OscInitStruct.LSIState = RCC_LSI_ON;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
	RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
	RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL3;
	RCC_OscInitStruct.PLL.PREDIV = RCC_PREDIV_DIV1;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}

    /**Initializes the CPU, AHB and APB busses clocks 
    */
	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
								  |RCC_CLOCKTYPE_PCLK1;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}

	PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART1;
	PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK1;
	if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}

    /**Configure the Systick interrupt time 
    */
	//HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

    /**Configure the Systick 
    */
	//HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

	/* SysTick_IRQn interrupt configuration */
	HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/* ADC init function */
static void MX_ADC_Init(void)
{

	ADC_ChannelConfTypeDef sConfig;

    /**Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion) 
    */
	hadc.Instance = ADC1;
	hadc.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV1;
	hadc.Init.Resolution = ADC_RESOLUTION_12B;
	hadc.Init.DataAlign = ADC_DATAALIGN_RIGHT;
	hadc.Init.ScanConvMode = ADC_SCAN_DIRECTION_FORWARD;
	hadc.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
	hadc.Init.LowPowerAutoWait = DISABLE;
	hadc.Init.LowPowerAutoPowerOff = DISABLE;
	hadc.Init.ContinuousConvMode = DISABLE;
	hadc.Init.DiscontinuousConvMode = DISABLE;
	hadc.Init.ExternalTrigConv = ADC_SOFTWARE_START;
	hadc.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
	hadc.Init.DMAContinuousRequests = DISABLE;
	hadc.Init.Overrun = ADC_OVR_DATA_PRESERVED;
	if (HAL_ADC_Init(&hadc) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}

    /**Configure for the selected ADC regular channel to be converted. 
    */
	sConfig.Channel = ADC_CHANNEL_0;
	sConfig.Rank = ADC_RANK_CHANNEL_NUMBER;
	sConfig.SamplingTime = ADC_SAMPLETIME_1CYCLE_5;
	if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}

    /**Configure for the selected ADC regular channel to be converted. 
    */
	sConfig.Channel = ADC_CHANNEL_1;
	if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}

    /**Configure for the selected ADC regular channel to be converted. 
    */
	sConfig.Channel = ADC_CHANNEL_2;
	if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}

    /**Configure for the selected ADC regular channel to be converted. 
    */
	sConfig.Channel = ADC_CHANNEL_3;
	if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}

}

/* CRC init function */
static void MX_CRC_Init(void)
{

	hcrc.Instance = CRC;
	hcrc.Init.DefaultPolynomialUse = DEFAULT_POLYNOMIAL_ENABLE;
	hcrc.Init.DefaultInitValueUse = DEFAULT_INIT_VALUE_ENABLE;
	hcrc.Init.InputDataInversionMode = CRC_INPUTDATA_INVERSION_NONE;
	hcrc.Init.OutputDataInversionMode = CRC_OUTPUTDATA_INVERSION_DISABLE;
	hcrc.InputDataFormat = CRC_INPUTDATA_FORMAT_BYTES;
	if (HAL_CRC_Init(&hcrc) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}

}

/* IWDG init function */
static void MX_IWDG_Init(void)
{

	hiwdg.Instance = IWDG;
	hiwdg.Init.Prescaler = IWDG_PRESCALER_64;
	hiwdg.Init.Window = 4095;
	hiwdg.Init.Reload = 4095;
	if (HAL_IWDG_Init(&hiwdg) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}

}

/* USART1 init function */
static void MX_USART1_UART_Init(void)
{

	huart1.Instance = USART1;
	huart1.Init.BaudRate = 115200;
	huart1.Init.WordLength = UART_WORDLENGTH_8B;
	huart1.Init.StopBits = UART_STOPBITS_1;
	huart1.Init.Parity = UART_PARITY_NONE;
	huart1.Init.Mode = UART_MODE_TX_RX;
	huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	//huart1.Init.OverSampling = UART_OVERSAMPLING_8;
	//huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
//	huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
	if (HAL_UART_Init(&huart1) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}
    HAL_UART_Receive_IT(&huart1, (uint8_t *)aRxBuffer, RXBUFFERSIZE);
}

/* WWDG init function */
static void MX_WWDG_Init(void)
{

	hwwdg.Instance = WWDG;
	hwwdg.Init.Prescaler = WWDG_PRESCALER_8;
	hwwdg.Init.Window = 64;
	hwwdg.Init.Counter = 64;
	hwwdg.Init.EWIMode = WWDG_EWI_DISABLE;
	if (HAL_WWDG_Init(&hwwdg) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}

}

/** Configure pins as 
        * Analog 
        * Input 
        * Output
        * EVENT_OUT
        * EXTI
*/
static void MX_GPIO_Init(void)
{

	GPIO_InitTypeDef GPIO_InitStruct;

	/* GPIO Ports Clock Enable */
	__HAL_RCC_GPIOF_CLK_ENABLE();
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8 
					  |GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12 
					  , GPIO_PIN_RESET);

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0|GPIO_PIN_1, GPIO_PIN_RESET);

	/*Configure GPIO pins : PA5 PA6 PA7 PA8 
							 PA9 PA10 PA11 PA12 
							 PA15 */
	GPIO_InitStruct.Pin = GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8 
                          |GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12 
                          |GPIO_PIN_15;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	/*Configure GPIO pins : PB0 PB1 */
	GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
   delay_ms(3);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5|GPIO_PIN_15, GPIO_PIN_SET);
}

/* USER CODE BEGIN 4 */
void Fmotor_cw(uint16_t N)
{
	//*FCW=FCW[i]
	uint16_t i,j,K;
	//uint16_t p;
	// *p = *FCW;
	for(j=0;j<N;j++)
	{
		//if(K3==0)
		//{
		//	break; //��� K3 ���£��˳���ѭ����ֹͣת��
		//}
		for(i=0;i<4;i++) //��ת 45 ��
		{
			//P1=CW[i];
			//delaynms(2); //����ת��
			K=GPIOA->ODR&0XF0FF;
			GPIOA->ODR=K|FCW[i];
			//HAL_GPIO_WritePin(GPIOA, (uint16_t)FCW[i], GPIO_PIN_SET);
			delay_ms(1);
			//GPIOA->ODR=GPIOA->ODR&0XF0FF;
		}
	}
}//�������
void Fmotor_ccw(uint16_t N)
{
	//*FCW=FCW[i]
	uint16_t i,j,K;
	//uint16_t p;
	// *p = *FCW;
	for(j=0;j<N;j++)
	{
		//if(K3==0)
		//{
		//	break; //��� K3 ���£��˳���ѭ����ֹͣת��
		//}
		for(i=0;i<4;i++) //��ת 45 ��
		{
			//P1=CW[i];
			//delaynms(2); //����ת��
			K=GPIOA->ODR&0XF0FF;
			GPIOA->ODR=K|FCCW[i];
			//HAL_GPIO_WritePin(GPIOA, (uint16_t)FCW[i], GPIO_PIN_SET);
			delay_ms(1);
			//GPIOA->ODR=GPIOA->ODR&0XF0FF;
		}
	}
}//�������
/* USER CODE END 4 */
void Fmotor_stop(uint16_t N)
{
	
		    uint16_t K;
			//P1=CW[i];
			//delaynms(2); //����ת��
			K=GPIOA->ODR&0XF0FF;
			GPIOA->ODR=K|0x0F00;
			//HAL_GPIO_WritePin(GPIOA, (uint16_t)FCW[i], GPIO_PIN_SET);
			delay_ms(N);
			//GPIOA->ODR=GPIOA->ODR&0XF0FF;	
}//�������
/* USER CODE BEGIN 4 */
void Zmotor_cw(uint16_t N)
{
	//*FCW=FCW[i]
	uint16_t i,j,K,B;
	K=0;
	B=0;
	//uint16_t p;
	// *p = *FCW;
	for(j=0;j<N;j++)
	{
		//if(K3==0)
		//{
		//	break; //��� K3 ���£��˳���ѭ����ֹͣת��
		//}
		for(i=0;i<4;i++) //��ת 45 ��
		{
			//P1=CW[i];
			//delaynms(2); //����ת��
			K=GPIOA->ODR&0XFF3F;
			B=GPIOB->ODR&0XFFFC;
			//GPIOA->ODR=z|ZACW[i];
			//B=GPIOB->ODR&0XFFFC;
			GPIOB->ODR=B|ZBCW[i];
			GPIOA->ODR=K|ZACW[i];
			//HAL_GPIO_WritePin(GPIOA, (uint16_t)FCW[i], GPIO_PIN_SET);
			delay_ms(1);
			//GPIOA->ODR=GPIOA->ODR&0XF0FF;
		}
	}
}//�������
/* USER CODE END 4 */
void Zmotor_ccw(uint16_t N)
{
	//*FCW=FCW[i]
	uint16_t i,j,K,B;
	K=0;
	B=0;
	//uint16_t p;
	// *p = *FCW;
	for(j=0;j<N;j++)
	{
		//if(K3==0)
		//{
		//	break; //��� K3 ���£��˳���ѭ����ֹͣת��
		//}
		for(i=0;i<4;i++) //��ת 45 ��
		{
			//P1=CW[i];
			//delaynms(2); //����ת��
			K=GPIOA->ODR&0XFF3F;
			B=GPIOB->ODR&0XFFFC;
			//GPIOA->ODR=z|ZACCW[i];
			GPIOB->ODR=B|ZBCCW[i];
			GPIOA->ODR=K|ZACCW[i];
			//HAL_GPIO_WritePin(GPIOA, (uint16_t)FCW[i], GPIO_PIN_SET);
			delay_ms(1);
			//GPIOA->ODR=GPIOA->ODR&0XF0FF;
		}
	}
}//�������
void Zmotor_stop(uint16_t N)
{
	//*FCW=FCW[i]
	uint16_t K,B;
	K=0;
	B=0;

			K=GPIOA->ODR&0XFF3F;
			B=GPIOB->ODR&0XFFFC;
			//GPIOA->ODR=z|ZACCW[i];
			GPIOB->ODR=B|0X0003;
			GPIOA->ODR=K|0X00C0;
			//HAL_GPIO_WritePin(GPIOA, (uint16_t)FCW[i], GPIO_PIN_SET);
			delay_ms(N);
			//GPIOA->ODR=GPIOA->ODR&0XF0FF;
}//�������
/**
  * @brief  This function is executed in case of error occurrence.
  * @param  None
  * @retval None
  */
void _Error_Handler(char * file, int line)
{
	/* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	while(1) 
	{
	}
	/* USER CODE END Error_Handler_Debug */ 
}

#ifdef USE_FULL_ASSERT

/**
   * @brief Reports the name of the source file and the source line number
   * where the assert_param error has occurred.
   * @param file: pointer to the source file name
   * @param line: assert_param error line source number
   * @retval None
   */
void assert_failed(uint8_t* file, uint32_t line)
{
	/* USER CODE BEGIN 6 */
	/* User can add his own implementation to report the file name and line number,
	  ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
	/* USER CODE END 6 */

}

#endif

/**
  * @}
  */ 

/**
  * @}
*/ 

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
