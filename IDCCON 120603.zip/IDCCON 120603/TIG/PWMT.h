#ifndef _PWMT_H
#define _PWMT_H
#include <stdio.h>
#include "stm32f0xx_hal.h"
#include <string.h>
//TIM_HandleTypeDef htim3;
void HAL_TIM_MspPostInit(TIM_HandleTypeDef* htim);
//void HAL_TIM_Base_MspInit(TIM_HandleTypeDef* htim_base);
void MX_TIM3_Init(void);
void HAL_TIM_PWM_MspInit(TIM_HandleTypeDef* htim_pwm);
#endif
