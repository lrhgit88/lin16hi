
#include "PWMT.h"	
void MX_TIM3_Init(void);
TIM_HandleTypeDef htim3;
uint16_t nduty=0;
uint16_t NFREQ=0;
extern  uint16_t TD ;
extern uint16_t F ;
//#define  NFREQ  (1000000/F)
//#define  Nduty  (TD*NFREQ/100)
//#define  NFREQ  (1000000/F)
 /* TIM3 init function */
 void MX_TIM3_Init(void)
{
  //TIM_MasterConfigTypeDef sMasterConfig;
  TIM_OC_InitTypeDef sConfigOC;
   NFREQ =(6000000/F);
   nduty  =(TD*NFREQ/100);
	//__HAL_RCC_TIM3_CLK_DISABLE();

  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 7;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = NFREQ-1;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = nduty;
  sConfigOC.OCPolarity = TIM_OCNPOLARITY_LOW;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  HAL_TIM_MspPostInit(&htim3); 
	//HAL_NVIC_SetPriority(TIM3_IRQn, 3, 0);
 // HAL_NVIC_EnableIRQ(TIM3_IRQn);
  TIM_CCxChannelCmd(TIM3, TIM_CHANNEL_2, TIM_CCx_ENABLE);
	__HAL_TIM_ENABLE(&htim3);
}

void HAL_TIM_MspPostInit(TIM_HandleTypeDef* htim)
{

	GPIO_InitTypeDef GPIO_InitStruct;
	if(htim->Instance==TIM3)
	{
	//	__HAL_RCC_GPIOB_CLK_ENABLE();
		/* USER CODE BEGIN TIM3_MspPostInit 0 */
//__HAL_RCC_TIM3_CLK_DISABLE();
		// __HAL_RCC_TIM3_CLK_ENABLE();
		/* USER CODE END TIM3_MspPostInit 0 */
		
		/**TIM3 GPIO Configuration    
		PB5     ------> TIM3_CH2 
		*/
		GPIO_InitStruct.Pin = GPIO_PIN_5;
		GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
		GPIO_InitStruct.Pull = GPIO_NOPULL;
		GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
		GPIO_InitStruct.Alternate = GPIO_AF1_TIM3;
		HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

		/* USER CODE BEGIN TIM3_MspPostInit 1 */

		/* USER CODE END TIM3_MspPostInit 1 */
	}

}

void HAL_TIM_PWM_MspInit(TIM_HandleTypeDef* htim_pwm)
{

  if(htim_pwm->Instance==TIM3)
  {
  /* USER CODE BEGIN TIM3_MspInit 0 */

  /* USER CODE END TIM3_MspInit 0 */
    /* Peripheral clock enable */
    __HAL_RCC_TIM3_CLK_ENABLE();
  /* USER CODE BEGIN TIM3_MspInit 1 */

  /* USER CODE END TIM3_MspInit 1 */
  }

}
